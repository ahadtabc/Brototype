const bcrypt = require("bcrypt");
const userService = require("../services/userService");

class UserController {
  async getLogin(req, res) {
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }

    if (req.session.passwordWrong) {
      req.session.passwordWrong = false;
      return res.render("user/login", {
        msg: "Invalid Credentials",
        msgClass: "text-danger ",
      });
    }

    if (req.session.signUpSuccess) {
      req.session.signUpSuccess = false;
      return res.render("user/login", {
        msg: "Sign up successful. Please log in.",
        msgClass: "text-success",
      });
    }

    res.render("user/login");
  }

  async postLogin(req, res) {
    try {
      const { email, password } = req.body;
      const existingUser = await userService.findUserByEmail(email);

      if (!existingUser || existingUser.role === "admin") {
        req.session.passwordWrong = true;
        return res.redirect("/login");
      }

      const isMatch = await bcrypt.compare(password, existingUser.password);

      if (!isMatch) {
        req.session.passwordWrong = true;
        return res.redirect("/login");
      }

      req.session.userLoggedIn = existingUser._id;
      res.redirect("/user/userDashboard");
    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while logging in";
      res.redirect("/login");
    }
  }

  async getDashboard(req, res) {
    try {
      const user = await userService.findUserById(req.session.userLoggedIn);
      res.render("user/home", { user });
    } catch (error) {
      console.error(error);
      res.redirect("/login");
    }
  }

  logout(req, res) {
    req.session.userLoggedIn = null;
    req.session.destroy((err) => {
      res.clearCookie("connect.sid");
      res.redirect("/login");
    });
  }

  getSignup(req, res) {
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }
    res.render("user/signup");
  }

  async postSignup(req, res) {
    try {
      const { name, email, password, confirmPassword } = req.body;

      const nameRegex = /^[A-Za-z ]+$/;
      if (!name || !nameRegex.test(name.trim())) {
        return res.render("user/signup", { error: "Name must contain only alphabets" });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailRegex.test(email.trim())) {
        return res.render("user/signup", { error: "Please provide a valid email address" });
      }

      if (!password || password.trim() === "") {
        return res.render("user/signup", { error: "Password is required" });
      }

      const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
      if (!passwordRegex.test(password)) {
        return res.render("user/signup", { error: "Password must be at least 8 characters long, contain a number, an uppercase and a lowercase letter." });
      }

      if (password !== confirmPassword) {
        return res.render("user/signup", { error: "Passwords do not match" });
      }

      const existingUser = await userService.findUserByEmail(email);
      if (existingUser) {
        return res.render("user/signup", { error: "Email is already registered" });
      }

      const hashedPassword = await bcrypt.hash(password, 12);

      await userService.createUser({
        name,
        email,
        password: hashedPassword,
      });

      req.session.signUpSuccess = true;
      req.session.save(() => {
        res.redirect("/login");
      });
    } catch (error) {
      console.error(error);
      res.render("user/signup", { error: "An error occurred while signing up" });
    }
  }
}

module.exports = new UserController();
