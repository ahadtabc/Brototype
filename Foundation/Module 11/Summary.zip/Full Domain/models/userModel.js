// ─────────────────────────────────────────────────────────────
// models/userModel.js — USER DATABASE SCHEMA
// This file defines the structure of a "user" document in MongoDB.
// Mongoose uses this schema to validate and save user data.
// ─────────────────────────────────────────────────────────────

// Import Mongoose — used to define schemas and interact with MongoDB
// Reason: Mongoose provides schema-based data modeling for MongoDB
const mongoose = require("mongoose");

// Define the schema (blueprint) for a user document in the database
// Reason: ensures every user document has the correct fields and data types
const userSchema = new mongoose.Schema({

  // The user's full name
  name: {
    type: String,       // Must be a text string
    required: true,     // Cannot be empty — every user must have a name
    trim: true,         // Automatically removes leading/trailing whitespace
  },

  // The user's email address (used for login)
  email: {
    type: String,       // Must be a text string
    required: true,     // Cannot be empty — required for authentication
    unique: true,       // Ensures no two users can have the same email
    trim: true,         // Removes extra whitespace automatically
  },

  // The user's password (stored as a bcrypt hash, not plain text)
  password: {
    type: String,       // Must be a string (the hashed password)
    required: true,     // Cannot be empty — every account must have a password
  },

  // The user's role — either "user" or "admin"
  role: {
    type: String,       // Must be a string
    default: "user",    // If no role is provided, it defaults to "user"
    // Reason: distinguishes regular users from admins without a separate collection
  },
});

// Create the "User" Mongoose model from the schema
// Reason: the model provides methods like User.find(), User.create() etc. to interact with the "users" collection in MongoDB
const User = mongoose.model("User", userSchema);

// Export the User model so it can be imported in services and other files
// Reason: other files (like userService.js) use this model to query the database
module.exports = User;
