// ─────────────────────────────────────────────────────────────
// models/adminModel.js — ADMIN DATABASE SCHEMA
// This file defines the structure of an "admin" document in MongoDB.
// Admins are stored in a separate "admins" collection — completely
// separate from the regular users collection.
// ─────────────────────────────────────────────────────────────

// Import Mongoose — used to define schemas and interact with MongoDB
// Reason: Mongoose provides schema-based data modeling for MongoDB
const mongoose = require("mongoose");

// Define the schema (blueprint) for an admin document in the database
// Reason: ensures every admin document has the correct fields and types
const adminSchema = new mongoose.Schema({

  // The admin's name
  name: {
    type: String,       // Must be a text string
    required: true,     // Cannot be empty
    trim: true,         // Removes leading/trailing whitespace automatically
  },

  // The admin's email address (used for admin login)
  email: {
    type: String,       // Must be a text string
    required: true,     // Cannot be empty
    unique: true,       // No two admins can share the same email
    trim: true,         // Removes extra whitespace automatically
  },

  // The admin's hashed password
  password: {
    type: String,       // Stored as a bcrypt hash string
    required: true,     // Cannot be empty
  }
});

// Create the "Admin" Mongoose model from the schema
// Reason: the model provides .find(), .create() etc. to query the "admins" MongoDB collection
const Admin = mongoose.model("Admin", adminSchema);

// Export the Admin model so it can be used in adminService.js and createAdmin.js
// Reason: modular exports allow reuse across different files
module.exports = Admin;
