// ─────────────────────────────────────────────────────────────
// services/adminService.js — ADMIN DATA ACCESS LAYER
// This file contains all database query functions used by the admin panel.
// It handles admin authentication queries AND all user CRUD operations
// (Create, Read, Update, Delete) that the admin performs.
// ─────────────────────────────────────────────────────────────

// Import the User model — used to manage regular users from the admin panel
// Reason: admin manages users, so it needs access to the users collection
const User = require("../models/userModel");

// Import the Admin model — used to look up admin accounts during login
// Reason: admin credentials are stored in a separate "admins" collection
const Admin = require("../models/adminModel");

// Define the AdminService class with all admin-related database operations
class AdminService {

    // Find and return an admin document by email
    // Reason: used during admin login to verify the admin exists
    async findAdminByEmail(email) {
        // Searches the "admins" collection for a document with the matching email
        return await Admin.findOne({ email });
    }

    // Fetch a paginated and searchable list of users (excludes admins)
    // Reason: the manage users page shows users in pages and supports search filtering
    async getPaginatedUsers(searchQuery, skip, limit) {
        // Build a MongoDB query object
        const query = {
            // $ne means "not equal" — excludes anyone with role "admin"
            // Reason: admins should not appear in the user list
            role: { $ne: "admin" },

            // $or means match if EITHER condition is true
            // Reason: allows searching by name OR by email simultaneously
            $or: [
                // $regex allows partial text matching; $options: "i" means case-insensitive
                { name: { $regex: searchQuery, $options: "i" } },
                { email: { $regex: searchQuery, $options: "i" } }
            ]
        };
        // Execute the query, skip documents for pagination, and limit how many are returned
        // .skip(skip) jumps past already-seen records, .limit(limit) caps the result count
        return await User.find(query).skip(skip).limit(limit);
    }

    // Count the total number of users that match the search query
    // Reason: needed to calculate how many pagination pages to display
    async getTotalUsersCount(searchQuery) {
        // Same query structure as getPaginatedUsers but uses countDocuments instead of find
        const query = {
            role: { $ne: "admin" },
            $or: [
                { name: { $regex: searchQuery, $options: "i" } },
                { email: { $regex: searchQuery, $options: "i" } }
            ]
        };
        // Returns the number of matching documents (not the documents themselves)
        return await User.countDocuments(query);
    }

    // Find a user in the users collection by their email
    // Reason: used to check if an email is already taken before creating/editing a user
    async findUserByEmail(email) {
        return await User.findOne({ email });
    }

    // Create a new user document in the users collection
    // Reason: used by the admin when manually adding a new user account
    async createUser(userData) {
        // Create a new User instance from the provided data
        const newUser = new User(userData);
        // Save the user document to MongoDB and return the result
        return await newUser.save();
    }

    // Find a single user by their MongoDB ID
    // Reason: used to pre-fill the edit form with the user's current data
    async findUserById(id) {
        return await User.findById(id);
    }

    // Update a user's fields in the database by their ID
    // Reason: called after the admin submits the edit user form
    async updateUser(id, updateData) {
        // findByIdAndUpdate: finds the document and applies the updateData changes
        // { new: true } returns the updated document instead of the old one
        return await User.findByIdAndUpdate(id, updateData, { new: true });
    }

    // Permanently delete a user from the database by their ID
    // Reason: called when the admin clicks the Delete button on a user
    async deleteUser(id) {
        // findByIdAndDelete removes the document with the given _id from MongoDB
        return await User.findByIdAndDelete(id);
    }
}

// Export a single shared instance of AdminService
// Reason: a single instance (singleton) is efficient and ensures consistent state
module.exports = new AdminService();
