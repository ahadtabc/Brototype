// ─────────────────────────────────────────────────────────────
// services/userService.js — USER DATA ACCESS LAYER
// This file contains all database query functions related to users.
// Controllers call these functions instead of querying the DB directly.
// Reason: separates database logic from business logic (clean architecture).
// ─────────────────────────────────────────────────────────────

// Import the User model to perform MongoDB operations on the users collection
// Reason: the service layer interacts with the database through the model
const User = require("../models/userModel");

// Define the UserService class containing all user-related DB operations
// Reason: grouping related functions into a class keeps the code organized
class UserService {

    // Find and return a single user whose email matches the given email
    // Reason: used during login to check if the user exists before verifying the password
    async findUserByEmail(email) {
        // User.findOne({ email }) queries MongoDB for the first document with this email
        // await pauses until the database returns a result
        return await User.findOne({ email });
    }

    // Find and return a single user by their unique MongoDB ID
    // Reason: used to load the current user's data for the dashboard after login
    async findUserById(id) {
        // User.findById(id) is shorthand for User.findOne({ _id: id })
        return await User.findById(id);
    }

    // Create a new user document in the database
    // Reason: called after successful signup validation to save the new user
    async createUser(userData) {
        // Create a new User instance with the provided data (name, email, hashedPassword)
        const newUser = new User(userData);
        // Save the new user document to MongoDB and return the saved document
        return await newUser.save();
    }
}

// Export a single shared instance of UserService
// Reason: a single instance (singleton) ensures efficient reuse across all controllers
module.exports = new UserService();
