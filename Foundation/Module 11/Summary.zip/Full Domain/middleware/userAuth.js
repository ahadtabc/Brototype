// ─────────────────────────────────────────────────────────────
// middleware/userAuth.js — USER AUTHENTICATION GUARD
// This is a middleware function that protects user-only routes.
// It runs BEFORE the controller for any protected route.
// If the user is not logged in, they are redirected to the login page.
// ─────────────────────────────────────────────────────────────

// Import the User model to verify the user still exists in the database
// Reason: a session might exist even if the user account was deleted — we must verify
const User = require("../models/userModel");

// Define the userAuth middleware as an async arrow function
// It accepts: req (request), res (response), next (proceed to next handler)
const userAuth = async (req, res, next) => {
  try {
    // Check if the user session exists (set during login)
    // req.session.userLoggedIn holds the user's MongoDB _id if they are logged in
    if (!req.session.userLoggedIn) {
      // If no session, the user is not logged in — send them to the login page
      // Reason: prevents unauthorized access to protected pages like the dashboard
      return res.redirect("/login");
    }

    // Even if the session exists, verify the user still exists in the database
    // Reason: an admin might have deleted the user, but their session cookie still exists
    const existingUser = await User.findById(req.session.userLoggedIn);

    if (!existingUser) {
      // If the user no longer exists in DB, destroy the session to clean up
      req.session.destroy(() => {
        // Redirect to the root/home after destroying the invalid session
        return res.redirect("/");
      });
      // Return here to stop further execution while session is being destroyed
      return;
    }

    // If session is valid AND user exists in DB, allow the request to continue
    // next() passes control to the next middleware or controller function
    next();
  } catch (error) {
    // If any unexpected error occurs, log it to the console
    console.error(error);
    // Redirect to the root page as a safe fallback
    return res.redirect("/");
  }
};

// Export the middleware function so it can be applied to routes in userRoute.js
module.exports = userAuth;
