// ─────────────────────────────────────────────────────────────
// middleware/adminAuth.js — ADMIN AUTHENTICATION GUARD
// This middleware protects all admin routes (except login).
// It runs BEFORE any protected admin controller function.
// If the admin is not logged in, they are redirected to /admin (the login page).
// ─────────────────────────────────────────────────────────────

// Import the Admin model to verify the admin still exists in the database
// Reason: the session might exist even if the admin account was removed
const Admin = require("../models/adminModel");

// Define the adminAuth middleware as an async arrow function
// It receives req, res, and next — the standard middleware signature in Express
const adminAuth = async (req, res, next) => {
    try {
        // Check if the admin session exists (set during admin login)
        // req.session.adminLoggedIn holds the admin's MongoDB _id if they are logged in
        if (!req.session.adminLoggedIn) {
            // If no session, redirect to the admin login page at /admin
            // Reason: blocks unauthorized access to admin management pages
            return res.redirect("/admin");
        }

        // Verify the admin account still exists in the database
        // Reason: protects against stale sessions for accounts that no longer exist
        const existingAdmin = await Admin.findById(req.session.adminLoggedIn);

        if (!existingAdmin) {
            // If admin is not found in DB, clear the invalid session value
            // Reason: removes the stale login indicator from the session
            req.session.adminLoggedIn = null;
            // Redirect to the admin login page
            return res.redirect("/admin");
        }

        // If session is valid AND admin exists in DB, allow the request to proceed
        // next() passes control to the next function (the actual controller)
        next();
    } catch (error) {
        // Log any unexpected errors for debugging purposes
        console.error(error);
        // Redirect to admin login as a safe fallback on error
        return res.redirect("/admin");
    }
};

// Export the middleware function so it can be used in adminRoute.js
module.exports = adminAuth;
