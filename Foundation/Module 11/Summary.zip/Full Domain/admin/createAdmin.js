// ─────────────────────────────────────────────────────────────
// admin/createAdmin.js — ONE-TIME ADMIN SEEDER SCRIPT
// This is NOT part of the web server. It is a standalone script
// run from the command line ONCE to create the first admin account
// in the database before the application is used.
//
// Usage:
//   node admin/createAdmin.js admin@mail.com SecurePass123
// ─────────────────────────────────────────────────────────────

// Load environment variables from .env so MONGO_URI is available
// Reason: this script connects directly to MongoDB and needs the URI from .env
require("dotenv").config();

// Import Mongoose to connect to MongoDB from the command line
const mongoose = require("mongoose");

// Import bcrypt to hash the admin's password before saving
// Reason: the admin password must be stored as a hash, just like user passwords
const bcrypt = require("bcrypt");

// Import the Admin model to create/check admin documents
const Admin = require("../models/adminModel");

// Read the email from command-line argument (process.argv[2])
// If no email is provided, default to "admin@test.com"
// process.argv is an array: [node, scriptPath, arg1, arg2, ...]
const email = process.argv[2] || "admin@test.com";

// Read the password from command-line argument (process.argv[3])
// If no password is provided, default to "admin123"
const password = process.argv[3] || "admin123";

// Define the async function that creates the admin account
const createAdmin = async () => {
  try {
    // Connect to MongoDB using the URI from .env
    await mongoose.connect(process.env.MONGO_URI);

    // Check if an admin with this email already exists in the database
    // Reason: prevents creating duplicate admin accounts accidentally
    const existing = await Admin.findOne({ email });

    if (existing) {
      // If the admin already exists, log a message and exit without creating another one
      console.log(`Admin already exists: ${email}`);
      process.exit(0); // Exit with code 0 (success — no error, just no action needed)
    }

    // Hash the password with bcrypt before saving
    // Cost factor 10 is a balance between security and performance for a setup script
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create and save the admin document in the "admins" collection
    await Admin.create({ name: "Admin", email, password: hashedPassword });

    // Log a confirmation message
    console.log(`Admin created: ${email}`);

    // Exit the script successfully
    process.exit(0);

  } catch (error) {
    // Log any error that occurred during the process
    console.log(error);
    // Exit with code 1 to signal that an error occurred
    process.exit(1);
  }
};

// Call the createAdmin function to actually run the script
createAdmin();
