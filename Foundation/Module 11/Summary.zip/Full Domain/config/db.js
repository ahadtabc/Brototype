// ─────────────────────────────────────────────────────────────
// config/db.js — DATABASE CONNECTION
// This file is responsible for connecting the application to MongoDB.
// It is called once when the app starts in app.js.
// ─────────────────────────────────────────────────────────────

// Import Mongoose — the library used to connect to and query MongoDB
// Reason: Mongoose provides a clean API for MongoDB operations and schema validation
const mongoose = require("mongoose");

// Define an async function that establishes the database connection
// Reason: database operations are asynchronous; using async/await makes the code readable
const connectDB = async () => {
  try {
    // Connect to MongoDB using the URI stored in the .env file
    // Reason: the URI contains the database address, username, and password — kept secret in .env
    await mongoose.connect(process.env.MONGO_URI);

    // Log a success message when connection is established
    // Reason: gives the developer a clear confirmation in the terminal
    console.log("MongoDB connected successfully");
  } catch (error) {
    // If connection fails, log the error message
    // Reason: tells the developer exactly why the connection failed
    console.log("MongoDB connection failed:", error.message);

    // Exit the Node.js process with an error code (1 = failure)
    // Reason: if there is no database, the app cannot function — better to crash early than silently fail
    process.exit(1);
  }
};

// Export the connectDB function so it can be imported and called in app.js
// Reason: exporting makes the function reusable and keeps the code modular
module.exports = connectDB;
