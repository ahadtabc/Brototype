// ─────────────────────────────────────────────────────────────
// routes/adminRoute.js — ADMIN URL ROUTE DEFINITIONS
// This file maps all /admin URL paths to the corresponding
// admin controller functions. Most routes are protected by adminAuth.
// ─────────────────────────────────────────────────────────────

// Import Express — needed to create a Router instance
const express = require("express");

// Create a new Router instance for admin routes
// Reason: separates admin routes from user routes and keeps app.js clean
const admin = express.Router();

// Import the AdminController — contains all admin logic functions
const adminController = require("../controllers/adminController");

// Import the adminAuth middleware — protects routes from unauthenticated access
// Reason: only logged-in admins should be able to access admin management pages
const adminAuth = require("../middleware/adminAuth");


// Admin login routes (public — no auth required)
// GET /admin → shows the admin login form
admin.get("/", adminController.getLogin);
// POST /admin/login → processes admin login credentials
admin.post("/login", adminController.postLogin);

// Admin dashboard (protected)
// GET /admin/adminDashboard → redirects to the manage users list
// adminAuth runs first to confirm the admin is logged in
admin.get("/adminDashboard", adminAuth, adminController.getDashboard);

// Manage users page (protected)
// GET /admin/adminUsers → shows all users with search and pagination
admin.get("/adminUsers", adminAuth, adminController.getUsers);

// Add user routes (protected)
// GET /admin/addUser → shows the add-user form
admin.get("/addUser", adminAuth, adminController.getAddUser);
// POST /admin/addUser → handles form submission and creates the user in the database
admin.post("/addUser", adminAuth, adminController.postAddUser);

// Edit user routes (protected)
// :id is a URL parameter — it will be the MongoDB _id of the user to edit
// GET /admin/editUser/:id → shows the edit form pre-filled with the user's current data
admin.get("/editUser/:id", adminAuth, adminController.getEditUser);
// POST /admin/editUser/:id → handles form submission and updates the user in the database
admin.post("/editUser/:id", adminAuth, adminController.postEditUser);

// Delete user route (protected)
// GET /admin/deleteUser/:id → deletes the user with the given :id
admin.get("/deleteUser/:id", adminAuth, adminController.deleteUser);

// Admin logout route (public — no auth needed to log out)
// GET /admin/logout → destroys admin session and redirects to admin login
admin.get("/logout", adminController.logout);

// Export the router so app.js can mount it with app.use("/admin", adminRoute)
module.exports = admin;