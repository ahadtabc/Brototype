// ─────────────────────────────────────────────────────────────
// routes/userRoute.js — USER URL ROUTE DEFINITIONS
// This file maps URL paths to the corresponding controller functions.
// It defines all public and protected user-facing routes.
// ─────────────────────────────────────────────────────────────

// Import Express — needed to create a Router instance
const express = require("express");

// Create a new Router instance for user routes
// Reason: Router keeps user routes separate from admin routes and from app.js
const user = express.Router();

// Import the UserController which contains the handler functions
// Reason: the controller holds the actual logic; the route just maps the URL to it
const userController = require("../controllers/userController");

// Import the userAuth middleware — guards protected routes
// Reason: placed between the route and controller to block unauthenticated access
const userAuth = require("../middleware/userAuth");


// Root route: visiting "/" redirects to "/login"
// Reason: the app has no home page — users start at login
user.get("/", (req, res) => {
    res.redirect("/login");
});

// Login routes
// GET /login → shows the login form
user.get("/login", userController.getLogin);
// POST /login → handles form submission, verifies credentials
user.post("/login", userController.postLogin);

// Signup routes
// GET /signup → shows the registration form
user.get("/signup", userController.getSignup);
// POST /signup → handles form submission, creates a new user account
user.post("/signup", userController.postSignup);

// Protected dashboard route
// GET /user/userDashboard → FIRST runs userAuth middleware, THEN renders the dashboard
// Reason: userAuth ensures only logged-in users can reach the dashboard
user.get("/user/userDashboard", userAuth, userController.getDashboard);

// Logout route
// GET /logout → destroys the session and redirects to login
user.get("/logout", userController.logout);

// Export the router so app.js can mount it with app.use("/", userRoute)
module.exports = user;