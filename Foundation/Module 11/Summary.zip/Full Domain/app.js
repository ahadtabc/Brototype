// ─────────────────────────────────────────────────────────────
// app.js — MAIN ENTRY POINT
// This is the first file Node.js runs. It wires together every
// part of the application: database, middleware, routes, and server.
// ─────────────────────────────────────────────────────────────

// Load environment variables from the .env file into process.env
// Reason: keeps secrets (DB password, session secret, port) out of source code
require("dotenv").config();

// Import the Express framework — the core of this web server
// Reason: Express simplifies routing, middleware, and HTTP handling
const express = require("express");

// Import the Handlebars view engine for rendering .hbs HTML template files
// Reason: allows dynamic HTML with variables like {{user.name}}
const hbs = require("hbs");

// Import express-session to manage user login sessions on the server
// Reason: sessions let the server "remember" who is logged in between requests
const session = require("express-session");

// Import nocache middleware to disable browser caching of pages
// Reason: prevents the browser from showing old/cached pages after logout
const nocache = require("nocache");

// Import the database connection function from the config folder
// Reason: centralizes the MongoDB connection logic in one place
const connectDB = require("./config/db");

// Import the admin route definitions
// Reason: all /admin URLs are handled by this router module
const adminRoute = require("./routes/adminRoute");

// Import the user route definitions
// Reason: all user-facing URLs (/, /login, /signup, /dashboard) are handled here
const userRoute = require("./routes/userRoute");

// Read the PORT from .env, or use 3001 as the default fallback
// Reason: allows the port to be configured per environment without code changes
const PORT = process.env.PORT || 3001;

// Create the Express application instance
// Reason: `app` is the object we attach all middleware and routes to
const app = express();

// Connect to MongoDB when the server starts
// Reason: the app cannot function without a database connection
connectDB();

// Serve static files (CSS, images, JS) from the "public/" folder
// Reason: allows the browser to load stylesheets and scripts directly
app.use(express.static("public"));

// Set Handlebars (.hbs) as the template engine for rendering views
// Reason: tells Express to use HBS when res.render() is called
app.set("view engine", "hbs");

// Parse form data submitted via HTML forms (application/x-www-form-urlencoded)
// extended: true allows nested objects in form data
// Reason: without this, req.body would be empty on POST form submissions
app.use(
  express.urlencoded({
    extended: true,
  }),
);

// Parse incoming JSON request bodies
// Reason: allows the server to read data sent as JSON (e.g. from fetch/AJAX)
app.use(express.json());

// Configure and enable server-side session storage
app.use(
  session({
    // secret: a private key used to sign/encrypt the session cookie
    // Reason: prevents attackers from forging or tampering with session data
    secret: process.env.SESSION_SECRET,

    // resave: false → do not save session to store if it was not modified
    // Reason: improves performance by avoiding unnecessary writes to the store
    resave: false,

    // saveUninitialized: false → do not save empty sessions (e.g. unauthenticated visitors)
    // Reason: saves storage and avoids creating sessions for every anonymous visitor
    saveUninitialized: false,

    cookie: {
      // maxAge: how long (in milliseconds) the session cookie is valid
      // 60 * 60 * 1000 = 1 hour
      // Reason: automatically logs out users after 1 hour of inactivity
      maxAge: 60 * 60 * 1000,
    },
  }),
);

// Apply the nocache middleware globally to all routes
// Reason: sends HTTP headers to prevent browsers from caching responses
app.use(nocache());

// Custom cache-control middleware — adds explicit no-cache headers to every response
app.use((req, res, next) => {
  // Instructs browser and proxies NOT to store or serve cached pages
  res.setHeader("Cache-Control", "no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0");
  // HTTP/1.0 compatibility: tells old proxies not to cache
  res.setHeader("Pragma", "no-cache");
  // Sets the expiry of the response to a past date, forcing re-fetch
  res.setHeader("Expires", "0");
  // Call next() to pass control to the next middleware or route
  next();
});


// Mount all user-facing routes at the root "/"
// Reason: URLs like /login, /signup, /dashboard are handled by userRoute
app.use("/", userRoute);

// Mount all admin routes at "/admin"
// Reason: URLs like /admin/login, /admin/addUser are handled by adminRoute
app.use("/admin", adminRoute);


// Global flash message middleware — runs after every request, before res.render
// Reason: passes session-stored success/error messages to the view
app.use((req, res, next) => {
  // Make the session success message available in all .hbs templates
  res.locals.success = req.session.success;
  // Make the session error message available in all .hbs templates
  res.locals.error = req.session.error;
  // Delete from session after reading, so messages only appear once
  delete req.session.success;
  // Delete error from session after reading it
  delete req.session.error;
  // Pass control to the next route handler
  next();
});

// Start the HTTP server and listen for incoming requests on PORT
// Reason: this actually boots the server and makes it accessible
app.listen(PORT, () => {
  // Log a confirmation message when the server is running
  console.log(`Server is running on port ${PORT}`);
});
