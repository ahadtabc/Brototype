// ─────────────────────────────────────────────────────────────
// controllers/adminController.js — ADMIN BUSINESS LOGIC
// This file handles all admin panel actions:
//   - Admin login and logout
//   - Viewing/searching/paginating users
//   - Adding, editing, and deleting user accounts
// Each method corresponds to a route defined in adminRoute.js.
// ─────────────────────────────────────────────────────────────

// Import bcrypt — used to compare hashed passwords during login and hash new passwords
// Reason: passwords are stored as hashes; bcrypt is needed to verify or create them
const bcrypt = require("bcrypt");

// Import adminService — provides all database query functions for the admin panel
// Reason: separates database logic from controller logic for cleaner, maintainable code
const adminService = require("../services/adminService");

// Define the AdminController class containing all handler methods
class AdminController {

  // ── GET /admin ─────────────────────────────────────────────
  // Shows the admin login page
  getLogin(req, res) {
    // If admin is already logged in, skip the login page and go to the user list
    // Reason: prevents showing the login form to an already authenticated admin
    if (req.session.adminLoggedIn) {
      return res.redirect("/admin/adminUsers");
    }
    // Render the admin login view
    res.render("admin/login");
  }

  // ── POST /admin/login ──────────────────────────────────────
  // Handles admin login form submission
  async postLogin(req, res) {
    try {
      // Destructure email and password from the submitted form
      const { email, password } = req.body;

      // Search for an admin in the "admins" collection by email
      const admin = await adminService.findAdminByEmail(email);

      // If no admin is found with that email, reject the login
      if (!admin) {
        return res.render("admin/login", { msg: "Invalid email or password" });
      }

      // Compare the submitted plain-text password with the stored bcrypt hash
      // Reason: bcrypt.compare safely checks the password without decrypting the hash
      const isMatch = await bcrypt.compare(password, admin.password);

      // If the password doesn't match, reject the login
      if (!isMatch) {
        return res.render("admin/login", { msg: "Invalid email or password" });
      }

      // Login successful — store the admin's MongoDB _id in the session
      // Reason: this session value is checked by adminAuth middleware on protected routes
      req.session.adminLoggedIn = admin._id;

      // Redirect to the manage users page
      res.redirect("/admin/adminUsers");

    } catch (error) {
      console.error(error);
      res.render("admin/login", { msg: "An error occurred while logging in" });
    }
  }

  // ── GET /admin/adminDashboard ──────────────────────────────
  // Simply redirects to the manage users page
  // Reason: the "dashboard" is the user management list itself
  getDashboard(req, res) {
    res.redirect("/admin/adminUsers");
  }

  // ── GET /admin/adminUsers ─────────────────────────────────
  // Fetches and displays the paginated, searchable list of all users
  async getUsers(req, res) {
    try {
      // Read the page number from the URL query string (e.g. ?page=2)
      // parseInt converts it from string to number; || 1 defaults to page 1
      const page = parseInt(req.query.page) || 1;

      // Read how many users to show per page (e.g. ?limit=7)
      // Defaults to 7 if not specified
      const limit = parseInt(req.query.limit) || 7;

      // Calculate how many documents to skip in the database
      // e.g. page 2 with limit 7 → skip 7 records (show records 8-14)
      const skip = (page - 1) * limit;

      // Read the search query from the URL (e.g. ?search=john)
      // Defaults to empty string (show all) if not specified
      const searchQuery = req.query.search || "";

      // Fetch the paginated user documents from the database
      const rawUsers = await adminService.getPaginatedUsers(
        searchQuery,
        skip,
        limit,
      );

      // Convert each Mongoose document to a plain JS object and add a row index number
      // Reason: Handlebars templates cannot call Mongoose document methods; plain objects are simpler
      const users = rawUsers.map((user, i) => {
        // .toObject() converts a Mongoose document to a plain JavaScript object
        // Fallback: if already a plain object, use it directly
        const u = user.toObject ? user.toObject() : user;
        // Add a sequential index number for the table rows (e.g., 1, 2, 3...)
        // skip + i + 1 ensures the index continues correctly across pages
        u.index = skip + i + 1;
        return u;
      });

      // Get the total count of users matching the search query
      // Reason: needed to calculate total number of pages for pagination
      const totalUsers = await adminService.getTotalUsersCount(searchQuery);

      // Calculate total number of pages using Math.ceil to round up
      // e.g. 15 users / 7 per page = 2.14 → ceil = 3 pages
      const totalPages = Math.ceil(totalUsers / limit);

      // Render the manage users view with all the data needed for the table and pagination
      res.render("admin/manageUsers", {
        users,                            // Array of user objects to display in the table
        currentPage: page,               // Current active page number
        totalPages,                      // Total number of pages (for "Page 1 of 3" display)
        searchQuery,                     // Pass search term back so the search box stays filled
        previousPage: page > 1 ? page - 1 : null, // Previous page number (null if on page 1)
        nextPage: page < totalPages ? page + 1 : null, // Next page number (null if on last page)
      });

    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while fetching users";
      res.redirect("/admin/adminUsers");
    }
  }

  // ── GET /admin/addUser ────────────────────────────────────
  // Shows the form for the admin to create a new user account
  getAddUser(req, res) {
    res.render("admin/addUser");
  }

  // ── POST /admin/addUser ───────────────────────────────────
  // Handles the add-user form submission — validates input and creates the user
  async postAddUser(req, res) {
    try {
      // Destructure all form fields from the request body
      const { name, email, password, confirmPassword } = req.body;

      // ── NAME VALIDATION ───────────────────────────────────
      // Check that name is at least 3 characters (after removing whitespace)
      if (!name || name.trim().length < 3) {
        return res.render("admin/addUser", { error: "Name must be at least 3 characters long" });
      }

      // Regex allowing only uppercase/lowercase letters and spaces
      const nameRegex = /^[A-Za-z ]+$/;
      if (!nameRegex.test(name.trim())) {
        return res.render("admin/addUser", { error: "Name must contain only alphabets" });
      }

      // ── EMAIL VALIDATION ───────────────────────────────────
      // Check that email is in a valid format (e.g. name@domain.com)
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailRegex.test(email.trim())) {
        return res.render("admin/addUser", { error: "Please provide a valid email address" });
      }

      // ── PASSWORD VALIDATION ───────────────────────────────
      // Check that password is not empty
      if (!password || password.trim() === "") {
        return res.render("admin/addUser", { error: "Password is required" });
      }

      // Strong password: min 8 chars, must have a digit, uppercase, and lowercase letter
      const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
      if (!passwordRegex.test(password)) {
        return res.render("admin/addUser", { error: "Password must be at least 8 characters long, contain a number, an uppercase and a lowercase letter." });
      }

      // Check that password and confirm password fields match
      if (password !== confirmPassword) {
        return res.render("admin/addUser", { error: "Passwords do not match" });
      }

      // ── DUPLICATE EMAIL CHECK ─────────────────────────────
      // Check if a user with this email already exists in the database
      const existingUser = await adminService.findUserByEmail(email);
      if (existingUser) {
        return res.render("admin/addUser", { error: "Email is already registered" });
      }

      // ── HASH AND SAVE ─────────────────────────────────────
      // Hash the password with bcrypt before saving
      // Reason: plain-text passwords must never be stored in the database
      const hashedPassword = await bcrypt.hash(password, 12);

      // Create the new user in the database
      await adminService.createUser({
        name,
        email,
        password: hashedPassword, // Store the bcrypt hash, not the raw password
        role: "user",             // Assign the "user" role explicitly (not admin)
      });

      // Store a success message in the session
      // Reason: will be displayed as a flash message on the manage users page
      req.session.success = "User added successfully";

      // Redirect to the manage users page
      res.redirect("/admin/adminUsers");

    } catch (error) {
      console.error(error);
      res.render("admin/addUser", { error: "An error occurred while adding the user" });
    }
  }

  // ── GET /admin/editUser/:id ───────────────────────────────
  // Shows the edit form pre-filled with the existing user's data
  async getEditUser(req, res) {
    try {
      // req.params.id extracts the :id value from the URL (the user's MongoDB _id)
      const user = await adminService.findUserById(req.params.id);

      // Render the edit view and pass the user data to pre-fill the form fields
      res.render("admin/editUser", { user });

    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while fetching the user";
      res.redirect("/admin/adminUsers");
    }
  }

  // ── POST /admin/editUser/:id ──────────────────────────────
  // Handles the edit-user form submission — validates and updates the user's data
  async postEditUser(req, res) {
    try {
      // Destructure the submitted form fields
      const { name, email, password } = req.body;

      // Prepare the update object with the new name and email
      // Reason: password is only added if a new one was provided
      const updatedData = { name, email };

      // ── NAME VALIDATION ───────────────────────────────────
      if (!name || name.trim().length < 3) {
        // Reconstruct a minimal user object to pass back to the view (to keep form filled)
        const user = { _id: req.params.id, name, email };
        return res.render("admin/editUser", { user, error: "Name must be at least 3 characters long" });
      }

      const nameRegex = /^[A-Za-z ]+$/;
      if (!nameRegex.test(name.trim())) {
        const user = { _id: req.params.id, name, email };
        return res.render("admin/editUser", { user, error: "Name must contain only alphabets" });
      }

      // ── EMAIL VALIDATION ───────────────────────────────────
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailRegex.test(email.trim())) {
        const user = { _id: req.params.id, name, email };
        return res.render("admin/editUser", { user, error: "Please provide a valid email address" });
      }

      // ── DUPLICATE EMAIL CHECK ─────────────────────────────
      // Check if the email is used by a DIFFERENT user
      const existingUser = await adminService.findUserByEmail(email);
      if (existingUser && existingUser._id.toString() !== req.params.id) {
        // .toString() converts MongoDB ObjectId to a plain string for comparison
        // Reason: the current user can keep their own email; only reject if ANOTHER user has it
        const user = { _id: req.params.id, name, email };
        return res.render("admin/editUser", { user, error: "Email is already registered by another user" });
      }

      // ── OPTIONAL PASSWORD UPDATE ──────────────────────────
      // Only update the password if a new one was actually provided
      // Reason: edit form has an optional password field — leaving it blank keeps the old password
      if (password && password.trim() !== "") {
        // Hash the new password before saving
        const hashedPassword = await bcrypt.hash(password, 12);
        // Add the hashed password to the update object
        updatedData.password = hashedPassword;
      }

      // Apply all the updated fields to the user document in MongoDB
      await adminService.updateUser(req.params.id, updatedData);

      // Store a success message for the flash notification
      req.session.success = "User updated successfully";

      // Save the session before redirecting to ensure the message is persisted
      req.session.save(() => {
        res.redirect("/admin/adminUsers");
      });

    } catch (error) {
      console.error(error);
      // Reconstruct the user object to pass form values back to the view on error
      const user = { _id: req.params.id, name: req.body.name, email: req.body.email };
      res.render("admin/editUser", { user, error: "An error occurred while updating the user" });
    }
  }

  // ── GET /admin/deleteUser/:id ─────────────────────────────
  // Permanently deletes a user from the database
  async deleteUser(req, res) {
    try {
      // Call the service to delete the user with the given ID from MongoDB
      await adminService.deleteUser(req.params.id);

      // Store a success flash message for the manage users page
      req.session.success = "User deleted successfully";

      // Redirect back to the user list
      res.redirect("/admin/adminUsers");

    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while deleting the user";
      res.redirect("/admin/adminUsers");
    }
  }

  // ── GET /admin/logout ─────────────────────────────────────
  // Logs the admin out by destroying their session
  logout(req, res) {
    // Explicitly set the logged-in flag to null first
    req.session.adminLoggedIn = null;

    // Destroy the entire session on the server to clear all session data
    req.session.destroy((err) => {
      if (err) {
        // If session destruction fails, redirect to the manage users page as a fallback
        return res.redirect("/admin/adminUsers");
      }
      // Clear the session cookie from the browser
      // Reason: prevents the browser from sending the old session ID on future requests
      res.clearCookie("connect.sid");
      // Redirect to the admin login page after successful logout
      res.redirect("/admin");
    });
  }
}

// Export a single instance of AdminController
// Reason: exporting an instance makes all methods directly accessible as route handlers
module.exports = new AdminController();
