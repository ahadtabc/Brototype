// ─────────────────────────────────────────────────────────────
// controllers/userController.js — USER BUSINESS LOGIC
// This file handles all user-facing actions: login, signup,
// dashboard rendering, and logout.
// Each method corresponds to a route defined in userRoute.js.
// ─────────────────────────────────────────────────────────────

// Import bcrypt — used to hash passwords and compare hashed passwords during login
// Reason: passwords must NEVER be stored as plain text; bcrypt secures them
const bcrypt = require("bcrypt");

// Import the userService — provides database query functions for user data
// Reason: keeps database logic separate from controller logic (clean architecture)
const userService = require("../services/userService");

// Define the UserController class containing all handler methods
class UserController {

  // ── GET /login ─────────────────────────────────────────────
  // Shows the login page, but also handles redirect and flash messages
  async getLogin(req, res) {

    // If the user is already logged in, redirect them to their dashboard
    // Reason: a logged-in user should not see the login form again
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }

    // If login failed (wrong password), show an error message
    // req.session.passwordWrong is set to true in postLogin when credentials are invalid
    if (req.session.passwordWrong) {
      // Reset the flag immediately so the message only shows once
      req.session.passwordWrong = false;
      return res.render("user/login", {
        msg: "Invalid Credentials",  // The error message shown to the user
        msgClass: "text-danger ",    // Bootstrap class for red text
      });
    }

    // If the user just completed signup successfully, show a success message
    // req.session.signUpSuccess is set to true in postSignup after account creation
    if (req.session.signUpSuccess) {
      // Reset the flag immediately so the message only shows once
      req.session.signUpSuccess = false;
      return res.render("user/login", {
        msg: "Sign up successful. Please log in.", // Success message
        msgClass: "text-success",                  // Bootstrap class for green text
      });
    }

    // If no special condition, just render the login page normally
    res.render("user/login");
  }

  // ── POST /login ─────────────────────────────────────────────
  // Handles login form submission — verifies credentials and creates a session
  async postLogin(req, res) {
    try {
      // Destructure email and password from the submitted form data
      // Reason: req.body contains all form field values
      const { email, password } = req.body;

      // Look up the user in the database by their email
      const existingUser = await userService.findUserByEmail(email);

      // If no user is found OR the found account is an admin account, reject the login
      // Reason: admins should not be able to log into the user panel
      if (!existingUser || existingUser.role === "admin") {
        req.session.passwordWrong = true; // Set flag to show error on the login page
        return res.redirect("/login");
      }

      // Compare the submitted plain-text password against the stored hashed password
      // bcrypt.compare returns true if they match, false otherwise
      const isMatch = await bcrypt.compare(password, existingUser.password);

      // If the password doesn't match, reject the login
      if (!isMatch) {
        req.session.passwordWrong = true; // Set flag to show error on redirect
        return res.redirect("/login");
      }

      // Login is successful — save the user's ID to the session to mark them as logged in
      // Reason: this session value is checked by userAuth middleware on every protected route
      req.session.userLoggedIn = existingUser._id;

      // Redirect the user to their dashboard
      res.redirect("/user/userDashboard");

    } catch (error) {
      // Log any unexpected server error
      console.error(error);
      // Save a generic error message to the session for display on the login page
      req.session.error = "An error occurred while logging in";
      res.redirect("/login");
    }
  }

  // ── GET /user/userDashboard ─────────────────────────────────
  // Shows the user's personal dashboard page
  async getDashboard(req, res) {
    try {
      // Fetch the full user object from the database using the session ID
      // Reason: the session only stores the _id; we need the full user data (name, email) for the view
      const user = await userService.findUserById(req.session.userLoggedIn);

      // Render the dashboard view and pass the user object to it
      // In the .hbs template, {{user.name}} will display the user's name
      res.render("user/home", { user });

    } catch (error) {
      console.error(error);
      // If anything goes wrong, redirect to the login page as a safe fallback
      res.redirect("/login");
    }
  }

  // ── GET /logout ─────────────────────────────────────────────
  // Logs the user out by destroying their session
  logout(req, res) {
    // Set the logged-in session value to null first
    // Reason: explicitly clearing it ensures it cannot be accessed after destroy
    req.session.userLoggedIn = null;

    // Destroy the entire session on the server
    // Reason: fully clears all session data so nothing persists after logout
    req.session.destroy((err) => {
      // Clear the session cookie from the browser
      // Reason: removes the cookie so the browser doesn't send it on future requests
      res.clearCookie("connect.sid");
      // Redirect to the login page after successful logout
      res.redirect("/login");
    });
  }

  // ── GET /signup ─────────────────────────────────────────────
  // Shows the signup (registration) form
  getSignup(req, res) {
    // If the user is already logged in, redirect them to the dashboard
    // Reason: a logged-in user does not need to register again
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }
    // Render the signup page
    res.render("user/signup");
  }

  // ── POST /signup ─────────────────────────────────────────────
  // Handles signup form submission — validates input and creates a new account
  async postSignup(req, res) {
    try {
      // Destructure all fields from the submitted form
      const { name, email, password, confirmPassword } = req.body;

      // ── NAME VALIDATION ──────────────────────────────────────
      // Check if name is at least 3 characters
      if (!name || name.trim().length < 3) {
        return res.render("user/signup", { error: "Name must be at least 3 characters long" });
      }

      // Regex that only allows letters (A-Z, a-z) and spaces
      // Reason: names should not contain numbers or special characters
      const nameRegex = /^[A-Za-z ]+$/;
      if (!nameRegex.test(name.trim())) {
        return res.render("user/signup", { error: "Name must contain only alphabets" });
      }

      // ── EMAIL VALIDATION ──────────────────────────────────────
      // Regex that validates the format: something@something.something
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailRegex.test(email.trim())) {
        return res.render("user/signup", { error: "Please provide a valid email address" });
      }

      // ── PASSWORD VALIDATION ───────────────────────────────────
      // Check that password is not empty
      if (!password || password.trim() === "") {
        return res.render("user/signup", { error: "Password is required" });
      }

      // Strong password regex:
      // (?=.*\d)     → must contain at least one digit
      // (?=.*[a-z])  → must contain at least one lowercase letter
      // (?=.*[A-Z])  → must contain at least one uppercase letter
      // .{8,}        → must be at least 8 characters long
      const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
      if (!passwordRegex.test(password)) {
        return res.render("user/signup", { error: "Password must be at least 6 characters long, contain a number, an uppercase and a lowercase letter." });
      }

      // Check that password and confirm password match
      if (password !== confirmPassword) {
        return res.render("user/signup", { error: "Passwords do not match" });
      }

      // ── DUPLICATE EMAIL CHECK ─────────────────────────────────
      // Check if the email is already registered in the database
      const existingUser = await userService.findUserByEmail(email);
      if (existingUser) {
        return res.render("user/signup", { error: "Email is already registered" });
      }

      // ── HASH PASSWORD ─────────────────────────────────────────
      // Hash the password with bcrypt using a cost factor of 12
      // Reason: the higher the number, the more secure (but slower) the hashing
      // NEVER store plain-text passwords in a database
      const hashedPassword = await bcrypt.hash(password, 12);

      // Create the new user in the database with the hashed password
      await userService.createUser({
        name,
        email,
        password: hashedPassword, // Store the hash, not the original password
      });

      // Set a success flag in the session to display a message on the login page
      req.session.signUpSuccess = true;

      // Save the session before redirecting to ensure the flag is persisted
      // Reason: without .save(), the redirect might happen before the session is written
      req.session.save(() => {
        res.redirect("/login"); // Go to login page after successful registration
      });

    } catch (error) {
      // Log the error for debugging
      console.error(error);
      // Show a generic error on the signup page
      res.render("user/signup", { error: "An error occurred while signing up" });
    }
  }
}

// Export a single instance of UserController
// Reason: exporting an instance means the methods can be used directly as route handlers
module.exports = new UserController();
