const express = require("express");
const user = express.Router();
const userController = require("../controllers/userController");
const userAuth = require("../middleware/userAuth");

// Cache control middleware
user.use((req, res, next) => {
    res.setHeader("Cache-Control", "no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0");
    next();
});

// Root route
user.get("/", (req, res) => {
    res.redirect("/login");
});

// Login routes
user.get("/login", userController.getLogin);
user.post("/login", userController.postLogin);

// Signup routes
user.get("/signup", userController.getSignup);
user.post("/signup", userController.postSignup);

// User dashboard route
user.get("/user/userDashboard", userAuth, userController.getDashboard);

// Logout route
user.get("/logout", userController.logout);

module.exports = user;