const express = require("express");
const admin = express.Router();
const adminController = require("../controllers/adminController");
const adminAuth = require("../middleware/adminAuth");

// Cache control middleware
admin.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0");
  next();
});

// Admin login routes
admin.get("/", adminController.getLogin);
admin.post("/login", adminController.postLogin);

// Admin dashboard route
admin.get("/adminDashboard", adminAuth, adminController.getDashboard);

// Manage users routes
admin.get("/adminUsers", adminAuth, adminController.getUsers);

// Add user routes
admin.get("/addUser", adminAuth, adminController.getAddUser);
admin.post("/addUser", adminAuth, adminController.postAddUser);

// Edit user routes
admin.get("/editUser/:id", adminAuth, adminController.getEditUser);
admin.post("/editUser/:id", adminAuth, adminController.postEditUser);

// Delete user route
admin.get("/deleteUser/:id", adminAuth, adminController.deleteUser);

// Logout route
admin.get("/logout", adminController.logout);

module.exports = admin;