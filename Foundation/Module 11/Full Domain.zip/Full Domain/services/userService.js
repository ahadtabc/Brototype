const User = require("../models/userModel");

class UserService {
    async findUserByEmail(email) {
        return await User.findOne({ email });
    }

    async findUserById(id) {
        return await User.findById(id);
    }

    async createUser(userData) {
        const newUser = new User(userData);
        return await newUser.save();
    }
}

module.exports = new UserService();
