const User = require("../models/userModel");
const Admin = require("../models/adminModel");

class AdminService {
    async findAdminByEmail(email) {
        return await Admin.findOne({ email });
    }

    async getPaginatedUsers(searchQuery, skip, limit) {
        const query = {
            $or: [
                { name: { $regex: searchQuery, $options: "i" } },
                { email: { $regex: searchQuery, $options: "i" } }
            ]
        };
        return await User.find(query).skip(skip).limit(limit);
    }

    async getTotalUsersCount(searchQuery) {
        const query = {
            $or: [
                { name: { $regex: searchQuery, $options: "i" } },
                { email: { $regex: searchQuery, $options: "i" } }
            ]
        };
        return await User.countDocuments(query);
    }

    async findUserByEmail(email) {
        return await User.findOne({ email });
    }

    async createUser(userData) {
        const newUser = new User(userData);
        return await newUser.save();
    }

    async findUserById(id) {
        return await User.findById(id);
    }

    async updateUser(id, updateData) {
        return await User.findByIdAndUpdate(id, updateData, { new: true });
    }

    async deleteUser(id) {
        return await User.findByIdAndDelete(id);
    }
}

module.exports = new AdminService();
