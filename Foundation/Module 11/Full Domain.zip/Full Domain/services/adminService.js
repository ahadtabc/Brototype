const User = require("../models/userModel");

class AdminService {
    async findAdminByEmail(email) {
        return await User.findOne({ email, role: "admin" });
    }

    async getPaginatedUsers(searchQuery, skip, limit) {
        const query = {
            role: { $ne: "admin" },
            $or: [
                { name: { $regex: searchQuery, $options: "i" } },
                { email: { $regex: searchQuery, $options: "i" } }
            ]
        };
        return await User.find(query).skip(skip).limit(limit);
    }

    async getTotalUsersCount(searchQuery) {
        const query = {
            role: { $ne: "admin" },
            $or: [
                { name: { $regex: searchQuery, $options: "i" } },
                { email: { $regex: searchQuery, $options: "i" } }
            ]
        };
        return await User.countDocuments(query);
    }

    async findUserByEmail(email) {
        return await User.findOne({ email });
    }

    async createUser(userData) {
        const newUser = new User(userData);
        return await newUser.save();
    }

    async findUserById(id) {
        return await User.findById(id);
    }

    async updateUser(id, updateData) {
        return await User.findByIdAndUpdate(id, updateData, { new: true });
    }

    async deleteUser(id) {
        return await User.findByIdAndDelete(id);
    }
}

module.exports = new AdminService();
