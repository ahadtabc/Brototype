const bcrypt = require("bcrypt");
const userService = require("../services/userService");

class UserController {
  async getLogin(req, res) {
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }

    if (req.session.passwordWrong) {
      req.session.passwordWrong = false;
      return res.render("user/login", {
        msg: "Invalid Credentials",
        msgClass: "text-danger ",
      });
    }

    if (req.session.signUpSuccess) {
      req.session.signUpSuccess = false;
      return res.render("user/login", {
        msg: "Sign up successful. Please log in.",
        msgClass: "text-success",
      });
    }

    res.render("user/login");
  }

  async postLogin(req, res) {
    try {
      const { email, password } = req.body;
      const existingUser = await userService.findUserByEmail(email);

      if (!existingUser || existingUser.role === "admin") {
        req.session.passwordWrong = true;
        return res.redirect("/login");
      }

      const isMatch = await bcrypt.compare(password, existingUser.password);

      if (!isMatch) {
        req.session.passwordWrong = true;
        return res.redirect("/login");
      }

      req.session.userLoggedIn = existingUser._id;
      res.redirect("/user/userDashboard");
    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while logging in";
      res.redirect("/login");
    }
  }

  async getDashboard(req, res) {
    try {
      const user = await userService.findUserById(req.session.userLoggedIn);
      res.render("user/home", { user });
    } catch (error) {
      console.error(error);
      res.redirect("/login");
    }
  }

  logout(req, res) {
    req.session.destroy((err) => {
      res.redirect("/login");
    });
  }

  getSignup(req, res) {
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }
    res.render("user/signup");
  }

  async postSignup(req, res) {
    try {
      const { name, email, password, confirmPassword } = req.body;

      if (password !== confirmPassword) {
        req.session.error = "Passwords do not match";
        return res.redirect("/signup");
      }

      const existingUser = await userService.findUserByEmail(email);
      if (existingUser) {
        req.session.error = "User already exists";
        return res.redirect("/signup");
      }

      const hashedPassword = await bcrypt.hash(password, 12);

      await userService.createUser({
        name,
        email,
        password: hashedPassword,
      });

      req.session.signUpSuccess = true;
      res.redirect("/login");
    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while signing up";
      res.redirect("/signup");
    }
  }
}

module.exports = new UserController();
