const bcrypt = require("bcrypt");
const adminService = require("../services/adminService");

class AdminController {
  getLogin(req, res) {
    if (req.session.adminLoggedIn) {
      return res.redirect("/admin/adminUsers");
    }
    res.render("admin/login");
  }

  async postLogin(req, res) {
    try {
      const { email, password } = req.body;
      const admin = await adminService.findAdminByEmail(email);
      if (!admin) {
        return res.redirect("/admin?error=" + encodeURIComponent("Invalid email or password"));
      }

      const isMatch = await bcrypt.compare(password, admin.password);
      if (!isMatch) {
        return res.redirect("/admin?error=" + encodeURIComponent("Invalid email or password"));
      }
      req.session.adminLoggedIn = admin._id;
      res.redirect("/admin/adminUsers");
    } catch (error) {
      console.error(error);
      res.redirect("/admin?error=" + encodeURIComponent("An error occurred while logging in"));
    }
  }

  getDashboard(req, res) {
    res.redirect("/admin/adminUsers");
  }

  async getUsers(req, res) {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 7;
      const skip = (page - 1) * limit;
      const searchQuery = req.query.search || "";

      const rawUsers = await adminService.getPaginatedUsers(
        searchQuery,
        skip,
        limit,
      );
      const users = rawUsers.map((user, i) => {
        const u = user.toObject ? user.toObject() : user;
        u.index = skip + i + 1;
        return u;
      });
      const totalUsers = await adminService.getTotalUsersCount(searchQuery);
      const totalPages = Math.ceil(totalUsers / limit);

      res.render("admin/manageUsers", {
        users,
        currentPage: page,
        totalPages,
        searchQuery,
        previousPage: page > 1 ? page - 1 : null,
        nextPage: page < totalPages ? page + 1 : null,
      });
    } catch (error) {
      console.error(error);
      res.redirect("/admin/adminUsers?error=" + encodeURIComponent("An error occurred while fetching users"));
    }
  }

  getAddUser(req, res) {
    res.render("admin/addUser");
  }

  async postAddUser(req, res) {
    try {
      const { name, email, password } = req.body;
      const existingUser = await adminService.findUserByEmail(email);
      if (existingUser) {
        return res.redirect("/admin/addUser?error=" + encodeURIComponent("User with this email already exists"));
      }

      const hashedPassword = await bcrypt.hash(password, 12);
      await adminService.createUser({
        name,
        email,
        password: hashedPassword,
        role: "user",
      });
      res.redirect("/admin/adminUsers?success=" + encodeURIComponent("User added successfully"));
    } catch (error) {
      console.error(error);
      res.redirect("/admin/addUser?error=" + encodeURIComponent("An error occurred while adding the user"));
    }
  }

  async getEditUser(req, res) {
    try {
      const user = await adminService.findUserById(req.params.id);
      res.render("admin/editUser", { user });
    } catch (error) {
      console.error(error);
      res.redirect("/admin/adminUsers?error=" + encodeURIComponent("An error occurred while fetching the user"));
    }
  }

  async postEditUser(req, res) {
    try {
      const { name, email, password } = req.body;
      const updatedData = { name, email };
      if (password && password.trim() !== "") {
        const hashedPassword = await bcrypt.hash(password, 12);
        updatedData.password = hashedPassword;
      }
      await adminService.updateUser(req.params.id, updatedData);
      res.redirect("/admin/adminUsers?success=" + encodeURIComponent("User updated successfully"));
    } catch (error) {
      console.error(error);
      res.redirect("/admin/adminUsers?error=" + encodeURIComponent("An error occurred while updating the user"));
    }
  }

  async deleteUser(req, res) {
    try {
      await adminService.deleteUser(req.params.id);
      res.redirect("/admin/adminUsers?success=" + encodeURIComponent("User deleted successfully"));
    } catch (error) {
      console.error(error);
      res.redirect("/admin/adminUsers?error=" + encodeURIComponent("An error occurred while deleting the user"));
    }
  }

  logout(req, res) {
    req.session.adminLoggedIn = null;
    req.session.destroy((err) => {
      if (err) {
        return res.redirect("/admin/adminUsers");
      }
      res.clearCookie("connect.sid");
      res.redirect("/admin");
    });
  }
}

module.exports = new AdminController();
