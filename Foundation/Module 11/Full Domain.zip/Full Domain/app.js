require("dotenv").config();
const express = require("express");
const hbs = require("hbs");
const session = require("express-session");
const nocache = require("nocache");
const connectDB = require("./config/db");
const adminRoute = require("./routes/adminRoute");
const userRoute = require("./routes/userRoute");
const PORT = process.env.PORT || 3001;
const app = express();

connectDB();

app.use(express.static("public"));
app.set("view engine", "hbs");

app.use(
  express.urlencoded({
    extended: true,
  }),
);

app.use(express.json());

app.use(
  session({
    secret: "my secret",
    resave: false,
    saveUninitialized: false,
  }),
);

app.use(nocache());

app.use("/", userRoute);
app.use("/admin", adminRoute);

app.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-store,no-cache,must-revalidate,private");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  next();
});

app.use((req, res, next) => {
  res.locals.success = req.session.success;
  res.locals.error = req.session.error;
  delete req.session.success;
  delete req.session.error;
  next();
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
