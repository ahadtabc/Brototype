const User = require("../models/userModel");

const userAuth = async (req, res, next) => {
  try {
    if (!req.session.userLoggedIn) {
      return res.redirect("/login");
    }
    const existingUser = await User.findById(req.session.userLoggedIn);
    if (!existingUser) {
      req.session.destroy(() => {
        return res.redirect("/");
      });
      return;
    }
    next();
  } catch (error) {
    console.error(error);
    return res.redirect("/");
  }
};

module.exports = userAuth;
