const User = require("../models/userModel");

const adminAuth = async (req, res, next) => {
    try {
        if (!req.session.adminLoggedIn) {
            return res.redirect("/admin");
        }
        const existingAdmin = await User.findById(req.session.adminLoggedIn);
        if (!existingAdmin || existingAdmin.role !== "admin") {
            req.session.adminLoggedIn = null;
            return res.redirect("/admin");
        }
        next();
    } catch (error) {
        console.error(error);
        return res.redirect("/admin");
    }
};

module.exports = adminAuth;
