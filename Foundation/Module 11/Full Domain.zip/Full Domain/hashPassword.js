const bcrypt = require("bcrypt");

const password = "adminroot";

const hashPassword = async () => {
  try {
    const hashedPassword = await bcrypt.hash(password, 12);
    console.log("Hashed Password:", hashedPassword);
  } catch (error) {
    console.log("Password hashing failed:", error.message);
  }
};

hashPassword();
