// ============================================================
// FILE: app.js
// ROLE IN MVC: Application Entry Point (Bootstrap / Glue Layer)
// PURPOSE: This is the main server file. It wires together all
//          MVC layers (Models via DB, Views via HBS, Controllers
//          via Routes) and starts the HTTP server.
// ============================================================

// --- 1. Load Environment Variables ---
// 'dotenv' reads the .env file and injects every KEY=VALUE pair
// into process.env so the rest of the app can access secrets
// without hard-coding them (e.g., MONGO_URI, SESSION_SECRET).
require("dotenv").config();

// --- 2. Import Core Framework ---
// 'express' is the web framework that handles HTTP requests,
// routing, middleware, and responses. It is the backbone of this MVC app.
const express = require("express");

// --- 3. Import View Engine ---
// 'hbs' (Handlebars) is the templating engine used for the VIEW layer.
// It allows us to render .hbs files and inject dynamic data into HTML.
const hbs = require("hbs");

// --- 4. Import Session Middleware ---
// 'express-session' creates and manages server-side sessions.
// A session stores data (e.g., userLoggedIn, adminLoggedIn) between
// HTTP requests, because HTTP is stateless by default.
const session = require("express-session");

// --- 5. Import No-Cache Middleware ---
// 'nocache' sets HTTP response headers that prevent browsers from
// caching sensitive pages (login, dashboard) so users can't press
// the Back button to re-enter after logging out.
const nocache = require("nocache");

// --- 6. Import Database Config (Model Layer support) ---
// connectDB is a function that opens the MongoDB connection.
// Without this, Mongoose models (User, Admin) cannot read/write data.
const connectDB = require("./config/db");

// --- 7. Import Route Files (MVC Router Layer) ---
// adminRoute handles all /admin/* URL paths.
// userRoute  handles all /        URL paths (root, login, signup, dashboard).
// Routes delegate requests to the correct Controller method.
const adminRoute = require("./routes/adminRoute");
const userRoute  = require("./routes/userRoute");

// --- 8. Read PORT from environment (or default to 3001) ---
// process.env.PORT allows deployment platforms (Heroku, Railway)
// to inject a dynamic port. If undefined, we fall back to 3001.
const PORT = process.env.PORT || 3001;

// --- 9. Create Express Application Instance ---
// app is the central Express object. All middleware and routes
// are registered on this object.
const app = express();

// --- 10. Connect to MongoDB ---
// Calling connectDB() here ensures the database is ready before
// any HTTP request tries to use a Mongoose Model.
connectDB();

// --- 11. Serve Static Files ---
// express.static("public") tells Express to serve any file inside
// the /public folder directly (CSS, images, client-side JS).
// URL: GET /style.css  →  reads file: public/style.css
app.use(express.static("public"));

// --- 12. Set Handlebars as the View Engine ---
// app.set("view engine", "hbs") tells Express that when a Controller
// calls res.render("user/login"), it should look for
// views/user/login.hbs and compile it with Handlebars.
app.set("view engine", "hbs");

// --- 13. Parse URL-Encoded Form Bodies ---
// When an HTML <form method="POST"> is submitted, the browser sends
// data as "application/x-www-form-urlencoded".
// This middleware parses that data and puts it in req.body.
// extended: true  →  supports nested objects (e.g., user[name]).
app.use(
  express.urlencoded({
    extended: true,
  }),
);

// --- 14. Parse JSON Bodies ---
// If a client sends JSON (e.g., a fetch() API call with
// Content-Type: application/json), this middleware parses it
// and places the result in req.body.
app.use(express.json());

// --- 15. Configure Session Store ---
// session() creates a session middleware with these options:
//   secret       – A secret string used to sign the session cookie.
//                  Changing it invalidates all existing sessions.
//   resave        – false: don't re-save the session if it wasn't modified.
//   saveUninitialized – false: don't create a session until data is stored.
//   cookie.maxAge – Session expires after 60 minutes (60*60*1000 ms).
app.use(
  session({
    secret: process.env.SESSION_SECRET, // read from .env for security
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 60 * 60 * 1000, // 1 hour in milliseconds
    },
  }),
);

// --- 16. Apply No-Cache Headers (via nocache package) ---
// nocache() automatically sets Cache-Control, Pragma, and Expires
// headers to prevent browsers from caching any response from this server.
app.use(nocache());

// --- 17. Additional Manual Cache-Control Headers ---
// This custom middleware reinforces cache prevention for maximum
// compatibility with older browsers and proxies.
// no-store      – don't store response in any cache at all.
// must-revalidate – cache must verify with the server before reusing.
// Pragma: no-cache    – HTTP/1.0 backward compatibility.
// Expires: 0          – marks the content as already expired.
app.use((req, res, next) => {
  res.setHeader(
    "Cache-Control",
    "no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0",
  );
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  next(); // pass control to the next middleware
});

// --- 18. Mount User Routes ---
// All requests to "/" and sub-paths (e.g., /login, /signup,
// /user/userDashboard) are handled by userRoute.
// The prefix "/" means these routes are at the root level.
app.use("/", userRoute);

// --- 19. Mount Admin Routes ---
// All requests to "/admin" and sub-paths (e.g., /admin/login,
// /admin/adminUsers) are handled by adminRoute.
app.use("/admin", adminRoute);

// --- 20. Flash Message Middleware ---
// This middleware runs AFTER routes. It transfers flash messages
// (stored temporarily in the session by Controllers) into
// res.locals so Handlebars templates can access them as
// {{success}} or {{error}} without extra code in every route.
// After reading, the messages are deleted from the session so they
// only appear once (one-time flash behavior).
app.use((req, res, next) => {
  res.locals.success = req.session.success; // pass success message to views
  res.locals.error   = req.session.error;   // pass error message to views
  delete req.session.success;               // clear from session after reading
  delete req.session.error;                 // clear from session after reading
  next(); // continue to the next middleware or route handler
});

// --- 21. Start the HTTP Server ---
// app.listen() binds the Express application to the specified PORT.
// The callback logs a confirmation message when the server is ready.
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
