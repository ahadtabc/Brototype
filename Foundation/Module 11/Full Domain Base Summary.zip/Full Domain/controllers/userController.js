// ============================================================
// FILE: controllers/userController.js
// ROLE IN MVC: CONTROLLER Layer — User-facing logic
// PURPOSE: Handles all HTTP request logic for the user-facing
//          side of the application. Each method corresponds to
//          one route defined in userRoute.js.
//
// MVC Concept: The CONTROLLER receives the request from the Route,
//   asks the SERVICE to do any database work, and then decides
//   which VIEW to render or which redirect to send back.
//   Controllers should NOT contain raw database queries.
//
// DATA FLOW:
//   Route → Controller → Service → Model → MongoDB
//   Route ← Controller ← Service ← Model ← MongoDB
// ============================================================

// --- 1. Import bcrypt ---
// 'bcrypt' is a hashing library. It is used to:
//   a) hash plain-text passwords before saving to DB (postSignup)
//   b) compare a submitted password against the stored hash (postLogin)
// We never store or compare plain-text passwords for security.
const bcrypt = require("bcrypt");

// --- 2. Import the User Service ---
// userService provides all database operations for users.
// The controller calls service methods instead of using the Model directly.
// This follows the principle of Separation of Concerns.
const userService = require("../services/userService");

// --- 3. Define the UserController Class ---
// All methods are grouped in a class for organisation.
// Methods are async where database calls are involved.
class UserController {

  // ─────────────────────────────────────────────
  // METHOD: getLogin (GET /login)
  // ─────────────────────────────────────────────
  // Renders the login page. Before rendering, it checks for
  // session flags set during redirects to show appropriate messages.
  async getLogin(req, res) {

    // If the user is already logged in, redirect them to the dashboard.
    // Prevents logged-in users from seeing the login form again.
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }

    // If the previous login attempt had the wrong password,
    // show an error message on the login page.
    // We first reset the flag so it only shows once.
    if (req.session.passwordWrong) {
      req.session.passwordWrong = false; // clear the flag (one-time message)
      return res.render("user/login", {
        msg: "Invalid Credentials",  // message text passed to the HBS template
        msgClass: "text-danger ",    // Bootstrap CSS class for red color
      });
    }

    // If the user just completed signup, show a success message
    // on the login page instructing them to log in.
    if (req.session.signUpSuccess) {
      req.session.signUpSuccess = false; // clear the flag (one-time message)
      return res.render("user/login", {
        msg: "Sign up successful. Please log in.",
        msgClass: "text-success", // Bootstrap CSS class for green color
      });
    }

    // Default: render the login page with no message.
    res.render("user/login");
  }

  // ─────────────────────────────────────────────
  // METHOD: postLogin (POST /login)
  // ─────────────────────────────────────────────
  // Processes the submitted login form. Validates credentials
  // and either creates a session or redirects with an error.
  async postLogin(req, res) {
    try {
      // Destructure email and password from the submitted form body.
      // req.body is populated by the express.urlencoded() middleware.
      const { email, password } = req.body;

      // Ask the service to find a user with this email in the DB.
      const existingUser = await userService.findUserByEmail(email);

      // If no user found, or the found account is an admin (role === "admin"),
      // deny login. Admins must use /admin to log in, not this form.
      if (!existingUser || existingUser.role === "admin") {
        req.session.passwordWrong = true; // set flag so getLogin shows the error
        return res.redirect("/login");    // redirect back to login page
      }

      // Use bcrypt to compare the submitted plain-text password
      // against the stored hashed password.
      // bcrypt.compare() returns true if they match, false otherwise.
      const isMatch = await bcrypt.compare(password, existingUser.password);

      // If passwords do not match, deny login.
      if (!isMatch) {
        req.session.passwordWrong = true; // flag for error message
        return res.redirect("/login");
      }

      // ✅ Authentication passed:
      // Store the user's _id in the session.
      // This is how we track "who is logged in" across requests.
      req.session.userLoggedIn = existingUser._id;

      // Redirect to the user dashboard.
      res.redirect("/user/userDashboard");

    } catch (error) {
      console.error(error); // log to terminal for debugging
      req.session.error = "An error occurred while logging in"; // flash message
      res.redirect("/login"); // return to login on unexpected error
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: getDashboard (GET /user/userDashboard)
  // ─────────────────────────────────────────────
  // Renders the user's home page. Protected by userAuth middleware.
  // Fetches fresh user data from DB to display the user's name.
  async getDashboard(req, res) {
    try {
      // req.session.userLoggedIn holds the user's _id.
      // We fetch the full user object to get their name for display.
      const user = await userService.findUserById(req.session.userLoggedIn);

      // Render views/user/home.hbs, passing the user object.
      // In the template: {{user.name}} displays their name.
      res.render("user/home", { user });

    } catch (error) {
      console.error(error);
      res.redirect("/login"); // fallback if session is invalid
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: logout (GET /logout)
  // ─────────────────────────────────────────────
  // Ends the user's session and clears the session cookie.
  logout(req, res) {
    // Explicitly null the login flag before destroying the session
    // (defensive coding in case destroy() is delayed).
    req.session.userLoggedIn = null;

    // req.session.destroy() removes the session from the server's
    // memory store and from MongoDB (if a persistent store is used).
    // The callback runs after destruction is complete.
    req.session.destroy((err) => {
      // res.clearCookie("connect.sid") removes the session cookie
      // from the user's browser. "connect.sid" is the default cookie
      // name used by express-session.
      res.clearCookie("connect.sid");

      // Redirect back to the login page after logout is complete.
      res.redirect("/login");
    });
  }

  // ─────────────────────────────────────────────
  // METHOD: getSignup (GET /signup)
  // ─────────────────────────────────────────────
  // Renders the signup/registration form.
  // Redirects already logged-in users away to their dashboard.
  getSignup(req, res) {
    // If already logged in, no reason to sign up again.
    if (req.session.userLoggedIn) {
      return res.redirect("/user/userDashboard");
    }
    // Render the signup form (views/user/signup.hbs).
    res.render("user/signup");
  }

  // ─────────────────────────────────────────────
  // METHOD: postSignup (POST /signup)
  // ─────────────────────────────────────────────
  // Processes the signup form: validates input, hashes password,
  // saves the new user, then redirects to login.
  async postSignup(req, res) {
    try {
      // Extract all four fields from the submitted form.
      // 'confirmPassword' is only used for validation; never saved.
      const { name, email, password, confirmPassword } = req.body;

      // --- Validate: Passwords Must Match ---
      // If the user typed different passwords in both fields, reject.
      // We render the signup page again WITH the error message.
      if (password !== confirmPassword) {
        return res.render("user/signup", { error: "Passwords do not match" });
      }

      // --- Check for Duplicate Email ---
      // Query the database to see if this email is already registered.
      const existingUser = await userService.findUserByEmail(email);
      if (existingUser) {
        // Email taken – show error on the signup page.
        return res.render("user/signup", { error: "Email is already registered" });
      }

      // --- Hash the Password ---
      // bcrypt.hash(password, 12) hashes the plain-text password.
      // '12' is the salt rounds: higher = more secure but slower.
      // 12 is a good balance for production use.
      const hashedPassword = await bcrypt.hash(password, 12);

      // --- Save the New User ---
      // Call the service's createUser method with the data object.
      // The password is already hashed before being passed here.
      await userService.createUser({
        name,
        email,
        password: hashedPassword, // NEVER save plain-text passwords
      });

      // --- Set a Flash Flag for the Login Page ---
      // signUpSuccess tells getLogin to display a "Sign up successful" message.
      req.session.signUpSuccess = true;

      // req.session.save() ensures the session is written to the store
      // BEFORE the redirect happens. Without this, the flag might not
      // be available in the next request.
      req.session.save(() => {
        res.redirect("/login"); // go to login after successful signup
      });

    } catch (error) {
      console.error(error);
      // Show a generic error on the signup page on unexpected failure.
      res.render("user/signup", { error: "An error occurred while signing up" });
    }
  }
}

// --- 4. Export a Singleton Instance ---
// 'new UserController()' creates one shared instance.
// userRoute.js uses it as:
//   userController.getLogin, userController.postLogin, etc.
module.exports = new UserController();
