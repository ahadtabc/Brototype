// ============================================================
// FILE: controllers/adminController.js
// ROLE IN MVC: CONTROLLER Layer — Admin panel logic
// PURPOSE: Handles all HTTP request logic for the admin panel.
//          Each method corresponds to one or more admin routes
//          defined in adminRoute.js.
//
// MVC Concept: The CONTROLLER receives a request from the Route
//   (via adminRoute.js, after passing the adminAuth middleware),
//   delegates data work to the SERVICE layer, and renders the
//   appropriate VIEW or performs a redirect.
//
// FEATURES HANDLED:
//   - Admin login / logout
//   - List users with search + pagination
//   - Add new user
//   - Edit existing user (name, email, optional password)
//   - Delete a user
// ============================================================

// --- 1. Import bcrypt ---
// Used to:
//   a) Verify admin's submitted password against the stored hash (postLogin)
//   b) Hash new passwords when an admin adds or updates a user
const bcrypt = require("bcrypt");

// --- 2. Import the Admin Service ---
// adminService handles all database queries for the admin panel.
// It operates on both the "admins" and "users" MongoDB collections.
const adminService = require("../services/adminService");

// --- 3. Define the AdminController Class ---
// Groups all admin route handlers as class methods.
class AdminController {

  // ─────────────────────────────────────────────
  // METHOD: getLogin (GET /admin)
  // ─────────────────────────────────────────────
  // Renders the admin login form (views/admin/login.hbs).
  // If the admin is already logged in, skip the form and
  // redirect directly to the user management page.
  getLogin(req, res) {
    // req.session.adminLoggedIn holds the admin's _id after login.
    // If it's set, the admin is already authenticated.
    if (req.session.adminLoggedIn) {
      return res.redirect("/admin/adminUsers"); // go to user list
    }
    // Render the login form for unauthenticated requests.
    res.render("admin/login");
  }

  // ─────────────────────────────────────────────
  // METHOD: postLogin (POST /admin/login)
  // ─────────────────────────────────────────────
  // Processes the admin login form submission.
  // Validates email and password against the "admins" collection.
  async postLogin(req, res) {
    try {
      // Destructure email and password from the submitted form body.
      // req.body is available because of express.urlencoded() in app.js.
      const { email, password } = req.body;

      // Ask the service to find an admin with the given email.
      // Queries only the "admins" collection (not "users").
      const admin = await adminService.findAdminByEmail(email);

      // If no admin with that email exists, reject the login.
      // We re-render the login form with a generic error to avoid
      // revealing whether the email or password was wrong (security best practice).
      if (!admin) {
        return res.render("admin/login", { msg: "Invalid email or password" });
      }

      // Compare the submitted plain-text password against the stored hash.
      // bcrypt.compare() is asynchronous and returns a Boolean.
      const isMatch = await bcrypt.compare(password, admin.password);

      // If the password doesn't match, show the same generic error.
      if (!isMatch) {
        return res.render("admin/login", { msg: "Invalid email or password" });
      }

      // ✅ Authentication passed:
      // Store the admin's _id in the session so subsequent requests
      // (checked by adminAuth middleware) know who is logged in.
      req.session.adminLoggedIn = admin._id;

      // Redirect to the user management page after successful login.
      res.redirect("/admin/adminUsers");

    } catch (error) {
      // Log the error for debugging and show a generic error on the login form.
      console.error(error);
      res.render("admin/login", { msg: "An error occurred while logging in" });
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: getDashboard (GET /admin/adminDashboard)
  // ─────────────────────────────────────────────
  // Currently just redirects to the user list page.
  // This method exists as a named route so the URL is meaningful.
  // Could be expanded later to show statistics or analytics.
  getDashboard(req, res) {
    res.redirect("/admin/adminUsers"); // for now, go straight to user list
  }

  // ─────────────────────────────────────────────
  // METHOD: getUsers (GET /admin/adminUsers)
  // ─────────────────────────────────────────────
  // Renders the main user management table with:
  //   - Paginated results (configurable page size)
  //   - Live search by name or email
  //   - Row numbering that respects the current page offset
  async getUsers(req, res) {
    try {
      // --- Parse Query Parameters from the URL ---
      // req.query contains URL query string values.
      // Example URL: /admin/adminUsers?page=2&limit=7&search=alice

      const page  = parseInt(req.query.page)  || 1; // current page, default 1
      const limit = parseInt(req.query.limit) || 7; // rows per page, default 7
      const skip  = (page - 1) * limit;             // how many documents to skip
      // Example: page=2, limit=7 → skip = (2-1)*7 = 7 (skip first 7 documents)

      const searchQuery = req.query.search || ""; // search text (empty string if absent)

      // --- Fetch Paginated Users from the Service ---
      // rawUsers is an array of Mongoose documents (not plain objects).
      const rawUsers = await adminService.getPaginatedUsers(searchQuery, skip, limit);

      // --- Add Row Index Numbers ---
      // We convert each Mongoose document to a plain JS object (.toObject())
      // and add an 'index' property for the "#" column in the table.
      // The index accounts for the skip offset so it's correct across pages.
      // Example: on page 2 (skip=7), first row is index 8.
      const users = rawUsers.map((user, i) => {
        const u   = user.toObject ? user.toObject() : user; // convert to plain object
        u.index   = skip + i + 1;                           // e.g., skip=7, i=0 → index=8
        return u;
      });

      // --- Get Total Count for Pagination ---
      // countDocuments uses the same search query so the page count
      // is accurate even when filtering by a search term.
      const totalUsers = await adminService.getTotalUsersCount(searchQuery);

      // --- Calculate Total Pages ---
      // Math.ceil() rounds up so partial pages still count.
      // Example: 15 users / 7 per page = 2.14 → 3 pages.
      const totalPages = Math.ceil(totalUsers / limit);

      // --- Render the Manage Users View ---
      // Pass all data the template needs to display the table and pagination.
      res.render("admin/manageUsers", {
        users,                                            // array of user objects
        currentPage: page,                               // current page number
        totalPages,                                      // total number of pages
        searchQuery,                                     // current search term (for input value)
        previousPage: page > 1 ? page - 1 : null,       // previous page number or null (disables button)
        nextPage:     page < totalPages ? page + 1 : null, // next page number or null
      });

    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while fetching users"; // flash error
      res.redirect("/admin/adminUsers"); // redirect and show the error
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: getAddUser (GET /admin/addUser)
  // ─────────────────────────────────────────────
  // Renders the "Create New User" form (views/admin/addUser.hbs).
  // No data needs to be passed; the form is empty for new input.
  getAddUser(req, res) {
    res.render("admin/addUser");
  }

  // ─────────────────────────────────────────────
  // METHOD: postAddUser (POST /admin/addUser)
  // ─────────────────────────────────────────────
  // Processes the "Add User" form:
  //   1. Checks for duplicate email
  //   2. Hashes the password
  //   3. Saves the new user to the database
  async postAddUser(req, res) {
    try {
      // Extract the three required fields from the form body.
      const { name, email, password } = req.body;

      // --- Check for Duplicate Email ---
      // The database also enforces uniqueness, but checking here allows
      // a friendly error message rather than a Mongoose validation error.
      const existingUser = await adminService.findUserByEmail(email);
      if (existingUser) {
        return res.render("admin/addUser", { error: "Email is already registered" });
      }

      // --- Hash the Password ---
      // Salt rounds = 12 (a secure default). bcrypt.hash() is async.
      const hashedPassword = await bcrypt.hash(password, 12);

      // --- Create the User in the Database ---
      // role: "user" is explicitly set so admins can't accidentally
      // create another admin through this interface.
      await adminService.createUser({
        name,
        email,
        password: hashedPassword,
        role: "user", // always assign the "user" role from the admin panel
      });

      // --- Set a Flash Success Message ---
      // req.session.success will be picked up by the flash middleware
      // in app.js and passed as res.locals.success to the next view.
      req.session.success = "User added successfully";

      // Redirect to the user list page to show the updated list.
      res.redirect("/admin/adminUsers");

    } catch (error) {
      console.error(error);
      res.render("admin/addUser", { error: "An error occurred while adding the user" });
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: getEditUser (GET /admin/editUser/:id)
  // ─────────────────────────────────────────────
  // Renders the edit user form pre-filled with the user's existing data.
  // ':id' is a URL parameter extracted from the URL by Express.
  // Example URL: /admin/editUser/64b1a2c3d4e5f67890abcdef
  async getEditUser(req, res) {
    try {
      // req.params.id extracts the ':id' value from the URL.
      const user = await adminService.findUserById(req.params.id);

      // Render the edit form with the user object.
      // Template accesses {{user.name}}, {{user.email}}, {{user._id}}.
      res.render("admin/editUser", { user });

    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while fetching the user";
      res.redirect("/admin/adminUsers");
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: postEditUser (POST /admin/editUser/:id)
  // ─────────────────────────────────────────────
  // Processes the edit form:
  //   1. Checks that the new email is not already taken by another user
  //   2. Optionally hashes a new password if provided
  //   3. Updates the user document in the database
  async postEditUser(req, res) {
    try {
      const { name, email, password } = req.body; // fields from the edit form

      // Build the update object with always-updated fields.
      const updatedData = { name, email };

      // --- Email Uniqueness Check ---
      // Find any user with the new email value.
      const existingUser = await adminService.findUserByEmail(email);

      // If another user (different _id) already uses this email, reject.
      // We compare _id strings: existingUser._id.toString() converts the
      // Mongoose ObjectId to a plain string for comparison.
      if (existingUser && existingUser._id.toString() !== req.params.id) {
        // Re-render the form with the user's data and an error message.
        const user = { _id: req.params.id, name, email };
        return res.render("admin/editUser", {
          user,
          error: "Email is already registered by another user",
        });
      }

      // --- Optional Password Update ---
      // Only hash and update the password if the admin typed a new one.
      // password.trim() removes whitespace; if blank, leave the password unchanged.
      if (password && password.trim() !== "") {
        const hashedPassword  = await bcrypt.hash(password, 12); // hash the new password
        updatedData.password  = hashedPassword; // add to the update object
      }

      // --- Save the Updated Data to the Database ---
      // adminService.updateUser() calls User.findByIdAndUpdate().
      await adminService.updateUser(req.params.id, updatedData);

      // Set flash success message.
      req.session.success = "User updated successfully";

      // req.session.save() ensures the session write completes before
      // the redirect happens, so the flash message is available on the next page.
      req.session.save(() => {
        res.redirect("/admin/adminUsers");
      });

    } catch (error) {
      console.error(error);
      // Re-construct the user object from req.body for the re-rendered form.
      const user = { _id: req.params.id, name: req.body.name, email: req.body.email };
      res.render("admin/editUser", { user, error: "An error occurred while updating the user" });
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: deleteUser (GET /admin/deleteUser/:id)
  // ─────────────────────────────────────────────
  // Permanently removes a user document from the database.
  // req.params.id is the MongoDB _id of the user to delete.
  async deleteUser(req, res) {
    try {
      // Call the service to delete the user by _id.
      // findByIdAndDelete removes the document from the "users" collection.
      await adminService.deleteUser(req.params.id);

      // Set a flash success message.
      req.session.success = "User deleted successfully";

      // Redirect back to the user list to reflect the deletion.
      res.redirect("/admin/adminUsers");

    } catch (error) {
      console.error(error);
      req.session.error = "An error occurred while deleting the user";
      res.redirect("/admin/adminUsers");
    }
  }

  // ─────────────────────────────────────────────
  // METHOD: logout (GET /admin/logout)
  // ─────────────────────────────────────────────
  // Ends the admin session and redirects to the admin login page.
  logout(req, res) {
    // Null the login flag before destroying the session (defensive coding).
    req.session.adminLoggedIn = null;

    // req.session.destroy() clears the session from the server store.
    // The callback provides an error object in case destruction fails.
    req.session.destroy((err) => {
      if (err) {
        // If session destruction fails, redirect to admin panel anyway.
        // We don't expose the error to the client.
        return res.redirect("/admin/adminUsers");
      }
      // Clear the session cookie from the browser.
      // "connect.sid" is the default express-session cookie name.
      res.clearCookie("connect.sid");

      // Redirect to the admin login page (GET /admin).
      res.redirect("/admin");
    });
  }
}

// --- 4. Export a Singleton Instance ---
// adminRoute.js uses this instance to bind route handlers:
//   admin.get("/", adminController.getLogin);
module.exports = new AdminController();
