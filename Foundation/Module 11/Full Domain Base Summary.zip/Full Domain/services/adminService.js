// ============================================================
// FILE: services/adminService.js
// ROLE IN MVC: SERVICE Layer — Admin operations
// PURPOSE: Centralises all database queries used by the admin
//          panel. The AdminController calls these methods instead
//          of querying models directly, keeping the Controller
//          clean and the data logic testable and reusable.
//
// This service manages TWO collections:
//   - "admins"  → for admin authentication (Admin model)
//   - "users"   → for CRUD operations on regular users (User model)
// ============================================================

// --- 1. Import the User Model ---
// Used to run CRUD operations on the "users" collection
// (list, add, edit, delete regular users from the admin panel).
const User = require("../models/userModel");

// --- 2. Import the Admin Model ---
// Used to authenticate the admin during login.
// Queries the "admins" collection, not the "users" collection.
const Admin = require("../models/adminModel");

// --- 3. Define AdminService Class ---
// Groups all admin-related database operations into one place.
class AdminService {

  // --- 4. findAdminByEmail(email) ---
  // PURPOSE: Retrieve an admin document by email for login verification.
  // USED BY: adminController.postLogin
  //
  // Admin.findOne({ email }) → searches the "admins" collection
  //   for a single document matching the email.
  // Returns: Admin document (with hashed password) or null if not found.
  async findAdminByEmail(email) {
    return await Admin.findOne({ email });
  }

  // --- 5. getPaginatedUsers(searchQuery, skip, limit) ---
  // PURPOSE: Fetch a page of users for the admin's user list table.
  //          Supports live search by name or email.
  // USED BY: adminController.getUsers
  //
  // PARAMETERS:
  //   searchQuery – the text the admin typed in the search box
  //   skip        – how many documents to skip (for pagination)
  //   limit       – maximum documents to return per page
  //
  // query object breakdown:
  //   role: { $ne: "admin" }  → $ne means "not equal".
  //     Excludes any user whose role is "admin" from the list.
  //     This prevents admins from accidentally editing or deleting
  //     themselves through the user management panel.
  //   $or: [...]  → Mongoose OR condition:
  //     returns documents matching EITHER name OR email.
  //     { name: { $regex: searchQuery, $options: "i" } }
  //       $regex – searches for the pattern (partial match)
  //       $options: "i" – case-insensitive (e.g., "alice" matches "Alice")
  //
  // .skip(skip)  → skips the first N documents (page offset)
  // .limit(limit) → caps the result at N documents (page size)
  async getPaginatedUsers(searchQuery, skip, limit) {
    const query = {
      role: { $ne: "admin" }, // exclude admin accounts from the list
      $or: [
        { name:  { $regex: searchQuery, $options: "i" } }, // search by name
        { email: { $regex: searchQuery, $options: "i" } }, // OR by email
      ],
    };
    return await User.find(query).skip(skip).limit(limit);
  }

  // --- 6. getTotalUsersCount(searchQuery) ---
  // PURPOSE: Count how many users match the search query.
  //          Used to calculate the total number of pages for pagination.
  // USED BY: adminController.getUsers
  //
  // The query is identical to getPaginatedUsers so the count
  // always matches what was fetched (consistent pagination).
  // User.countDocuments(query) → returns an integer count,
  //   not the documents themselves (more efficient than fetching all).
  async getTotalUsersCount(searchQuery) {
    const query = {
      role: { $ne: "admin" }, // same filter as getPaginatedUsers
      $or: [
        { name:  { $regex: searchQuery, $options: "i" } },
        { email: { $regex: searchQuery, $options: "i" } },
      ],
    };
    return await User.countDocuments(query); // returns a number, not documents
  }

  // --- 7. findUserByEmail(email) ---
  // PURPOSE: Check if an email already exists in the "users" collection.
  // USED BY: adminController.postAddUser  (prevent duplicate registration)
  //          adminController.postEditUser (prevent email collision on update)
  //
  // Returns: User document or null.
  async findUserByEmail(email) {
    return await User.findOne({ email });
  }

  // --- 8. createUser(userData) ---
  // PURPOSE: Insert a new user document into the "users" collection.
  // USED BY: adminController.postAddUser
  //
  // new User(userData) → builds an in-memory Mongoose document.
  // newUser.save()     → persists it to MongoDB and validates the schema.
  // Returns: the saved document with auto-generated _id.
  async createUser(userData) {
    const newUser = new User(userData); // instantiate the document
    return await newUser.save();        // write to database
  }

  // --- 9. findUserById(id) ---
  // PURPOSE: Retrieve a user by their MongoDB _id.
  // USED BY: adminController.getEditUser (pre-fill the edit form)
  //
  // User.findById(id) → looks for a document with _id == id.
  // Returns: User document or null.
  async findUserById(id) {
    return await User.findById(id);
  }

  // --- 10. updateUser(id, updateData) ---
  // PURPOSE: Update specific fields of a user document.
  // USED BY: adminController.postEditUser
  //
  // User.findByIdAndUpdate(id, updateData, { new: true })
  //   id         – the _id of the user to update
  //   updateData – object containing fields to change (e.g., { name, email })
  //   { new: true } – returns the UPDATED document instead of the old one.
  //                   Without this option, Mongoose returns the pre-update doc.
  async updateUser(id, updateData) {
    return await User.findByIdAndUpdate(id, updateData, { new: true });
  }

  // --- 11. deleteUser(id) ---
  // PURPOSE: Permanently remove a user document from the database.
  // USED BY: adminController.deleteUser
  //
  // User.findByIdAndDelete(id) → finds the document with _id == id
  //   and deletes it from the "users" collection in a single operation.
  // Returns: the deleted document (or null if not found).
  async deleteUser(id) {
    return await User.findByIdAndDelete(id);
  }
}

// --- 12. Export a Singleton Instance ---
// Exports a single shared instance so all importers
// use the same AdminService object (singleton pattern).
module.exports = new AdminService();
