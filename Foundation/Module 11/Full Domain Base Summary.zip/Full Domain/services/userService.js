// ============================================================
// FILE: services/userService.js
// ROLE IN MVC: SERVICE Layer (sits between Controller & Model)
// PURPOSE: Encapsulates all database operations related to Users.
//          Controllers call Service methods instead of querying
//          the Model directly. This keeps Controllers thin and
//          makes data logic reusable and testable independently.
//
// MVC + Service Pattern:
//   Request → Route → Controller → Service → Model → MongoDB
//   Response ← Controller ← Service ← Model ← MongoDB
// ============================================================

// --- 1. Import the User Model ---
// The User Model is our gateway to the "users" MongoDB collection.
// Every method in this Service uses it to run queries.
const User = require("../models/userModel");

// --- 2. Define UserService Class ---
// Using a class keeps related database methods organised together.
// An instance is exported (not the class itself) so all importers
// share the same object (singleton pattern).
class UserService {

  // --- 3. findUserByEmail(email) ---
  // PURPOSE: Look up a single user document whose email matches.
  // USED BY: userController.postLogin (to verify login credentials)
  //          userController.postSignup (to check for duplicate emails)
  //
  // User.findOne({ email }) → Mongoose query that searches the
  //   "users" collection for the first document where the email
  //   field equals the provided value.
  // Returns: the User document if found, or null if not found.
  // 'await' pauses until MongoDB responds.
  async findUserByEmail(email) {
    return await User.findOne({ email });
  }

  // --- 4. findUserById(id) ---
  // PURPOSE: Retrieve a user by their unique MongoDB _id field.
  // USED BY: userController.getDashboard (to load the logged-in user's data)
  //
  // User.findById(id) → shorthand for User.findOne({ _id: id }).
  // The id comes from req.session.userLoggedIn, which stores the
  // user's _id after a successful login.
  // Returns: the User document, or null if no matching _id exists.
  async findUserById(id) {
    return await User.findById(id);
  }

  // --- 5. createUser(userData) ---
  // PURPOSE: Insert a new user document into the "users" collection.
  // USED BY: userController.postSignup (after validating and hashing password)
  //
  // new User(userData) → creates an in-memory Mongoose document
  //   from the provided data object { name, email, password }.
  // newUser.save() → writes the document to MongoDB.
  //   This triggers Mongoose schema validation (required fields, unique email).
  // Returns: the saved document including the auto-generated _id.
  async createUser(userData) {
    const newUser = new User(userData); // create a new Mongoose document instance
    return await newUser.save();        // persist (save) it to the database
  }
}

// --- 6. Export a Singleton Instance ---
// 'new UserService()' creates one instance.
// All files that require() this module share the same instance.
// This is memory-efficient and follows the Service pattern.
module.exports = new UserService();
