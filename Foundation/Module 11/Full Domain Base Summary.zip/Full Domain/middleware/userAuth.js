// ============================================================
// FILE: middleware/userAuth.js
// ROLE IN MVC: Middleware Layer (Route Guard for User Routes)
// PURPOSE: Protects routes that require a logged-in user.
//          If the user is not authenticated, they are redirected
//          to the login page instead of accessing the resource.
//
// MVC Flow:
//   Request → Route → [userAuth middleware] → Controller
//   If not authenticated → redirect to /login (never reaches Controller)
// ============================================================

// --- 1. Import the User Model ---
// We import the User Model directly here to verify that the
// session's stored user ID still corresponds to a real user
// in the database (guards against deleted accounts still holding sessions).
const User = require("../models/userModel");

// --- 2. Define the userAuth Middleware Function ---
// A middleware function in Express has the signature:
//   (req, res, next) => { ... }
//   req  – the incoming HTTP request object (headers, session, body)
//   res  – the outgoing HTTP response object (redirect, render, send)
//   next – a function that, when called, passes control to the
//           next middleware or route handler in the stack.
//
// 'async' allows using 'await' for the database query inside.
const userAuth = async (req, res, next) => {

  // --- 3. Try / Catch for Error Safety ---
  // Database queries can throw errors (connection issue, invalid ID).
  // The catch block ensures the server never crashes from this middleware.
  try {

    // --- 4. Check Session for Login Status ---
    // req.session.userLoggedIn is set to the user's MongoDB _id
    // when they successfully log in (see userController.postLogin).
    // If it does not exist (undefined/null), the user is NOT logged in.
    if (!req.session.userLoggedIn) {
      // Redirect the unauthenticated request to the login page.
      // 'return' ensures no further code in this function runs.
      return res.redirect("/login");
    }

    // --- 5. Verify User Still Exists in Database ---
    // Even if the session says the user is logged in, the user
    // account might have been deleted by an admin while the session
    // was still active. We query the database to confirm existence.
    // User.findById() searches for a document with the stored _id.
    const existingUser = await User.findById(req.session.userLoggedIn);

    // --- 6. Handle Non-Existent User ---
    // If no document was found (account deleted), we destroy the
    // session to clear the invalid login state and redirect to root.
    if (!existingUser) {
      req.session.destroy(() => {
        // 'return' inside the destroy callback exits the callback.
        return res.redirect("/");
      });
      return; // exit the outer function immediately after calling destroy
    }

    // --- 7. Pass to Next Handler ---
    // If the user is logged in AND exists in the database,
    // call next() to allow the request to proceed to the
    // actual route handler (Controller method).
    next();

  } catch (error) {

    // --- 8. Log and Redirect on Error ---
    // Any unexpected error (e.g., Mongoose connection error)
    // is logged to the console and the user is redirected
    // to the root rather than seeing a server error page.
    console.error(error);
    return res.redirect("/");
  }
};

// --- 9. Export the Middleware ---
// Exported so userRoute.js can use it as a route guard:
//   user.get("/user/userDashboard", userAuth, userController.getDashboard);
module.exports = userAuth;
