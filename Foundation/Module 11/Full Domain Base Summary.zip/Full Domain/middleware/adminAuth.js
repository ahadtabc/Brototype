// ============================================================
// FILE: middleware/adminAuth.js
// ROLE IN MVC: Middleware Layer (Route Guard for Admin Routes)
// PURPOSE: Protects every admin-only route.
//          Only requests with a valid admin session are allowed
//          to reach the AdminController. All others are
//          redirected to the admin login page (/admin).
//
// MVC Flow:
//   Request → Route → [adminAuth middleware] → Controller
//   If not authenticated → redirect to /admin (login page)
// ============================================================

// --- 1. Import the Admin Model ---
// Used to verify that the session's admin ID still corresponds
// to an actual document in the "admins" collection.
// This prevents ghost sessions from deleted admin accounts.
const Admin = require("../models/adminModel");

// --- 2. Define the adminAuth Middleware Function ---
// Standard Express middleware signature: (req, res, next)
//   req  – incoming request carrying session data
//   res  – response object used to redirect unauthenticated requests
//   next – call this to pass the request to the next handler
//
// 'async' is needed because we query MongoDB with 'await'.
const adminAuth = async (req, res, next) => {

  // --- 3. Wrap in try/catch ---
  // Protects against unexpected errors (e.g., invalid ObjectId format,
  // database timeout) that would otherwise crash the middleware.
  try {

    // --- 4. Check if Admin Session Exists ---
    // req.session.adminLoggedIn is set to the admin's _id
    // when they successfully log in (see adminController.postLogin).
    // If it is not set, the request is unauthenticated.
    if (!req.session.adminLoggedIn) {
      // Redirect to the admin login page (GET /admin renders the login form).
      // 'return' prevents any code after this from executing.
      return res.redirect("/admin");
    }

    // --- 5. Verify Admin Account Still Exists in DB ---
    // Even with a valid session, the admin document might have been
    // deleted from the database. We look it up to confirm validity.
    // Admin.findById() queries the "admins" collection by _id.
    const existingAdmin = await Admin.findById(req.session.adminLoggedIn);

    // --- 6. Handle Non-Existent Admin ---
    // If the admin document no longer exists (e.g., deleted externally),
    // clear the adminLoggedIn session value and redirect to login.
    // We explicitly set it to null rather than destroying the whole session
    // (different from userAuth which destroys the whole session).
    if (!existingAdmin) {
      req.session.adminLoggedIn = null; // clear the invalid session value
      return res.redirect("/admin");    // send back to admin login
    }

    // --- 7. Allow Access ---
    // Admin is authenticated and account exists in the database.
    // Call next() to proceed to the Controller method that
    // was originally requested.
    next();

  } catch (error) {

    // --- 8. Error Fallback ---
    // Log the error for debugging and redirect to the admin
    // login page to prevent exposing internal error details.
    console.error(error);
    return res.redirect("/admin");
  }
};

// --- 9. Export the Middleware ---
// Used in adminRoute.js to protect all admin-only routes:
//   admin.get("/adminUsers", adminAuth, adminController.getUsers);
module.exports = adminAuth;
