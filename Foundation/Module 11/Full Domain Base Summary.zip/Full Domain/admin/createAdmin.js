// ============================================================
// FILE: admin/createAdmin.js
// ROLE IN MVC: Utility Script (outside the MVC request cycle)
// PURPOSE: A one-time setup script run from the command line to
//          create the initial admin account in the "admins"
//          MongoDB collection. This is NOT a web route — it
//          runs directly with Node.js.
//
// USAGE:
//   node admin/createAdmin.js [email] [password]
//   Example: node admin/createAdmin.js admin@test.com mySecret123
//
//   If no arguments are given, defaults are used:
//     email:    admin@test.com
//     password: admin123
//
// WHY THIS EXISTS:
//   There is no public "Create Admin" web form (that would be
//   a security risk). Instead, the developer runs this script
//   once after setting up the project to seed the first admin.
// ============================================================

// --- 1. Load Environment Variables ---
// Required before accessing process.env.MONGO_URI.
// dotenv reads the .env file in the project root.
require("dotenv").config();

// --- 2. Import Mongoose ---
// Used here to connect directly to MongoDB outside of app.js.
// This script manages its own lifecycle: connect → do work → exit.
const mongoose = require("mongoose");

// --- 3. Import bcrypt ---
// Used to hash the admin's password before saving it to the database.
// We NEVER store plain-text passwords, even in seed scripts.
const bcrypt = require("bcrypt");

// --- 4. Import the Admin Model ---
// Provides the Mongoose interface to the "admins" collection.
// Admin.findOne() checks if an admin already exists.
// Admin.create() inserts a new admin document.
const Admin = require("../models/adminModel");

// --- 5. Read Command-Line Arguments ---
// process.argv is an array of strings:
//   process.argv[0] = path to Node.js executable (e.g., /usr/bin/node)
//   process.argv[1] = path to this script file (createAdmin.js)
//   process.argv[2] = first user-provided argument (email)
//   process.argv[3] = second user-provided argument (password)
//
// If not provided, use sensible defaults for local development.
const email    = process.argv[2] || "admin@test.com"; // default email
const password = process.argv[3] || "admin123";        // default password (CHANGE IN PRODUCTION!)

// --- 6. Define the createAdmin Async Function ---
// Wrapped in async so we can use 'await' for all database operations.
const createAdmin = async () => {
  try {

    // --- 7. Connect to MongoDB ---
    // Opens a database connection using the URI from .env.
    // This is done here because app.js (which calls connectDB()) is
    // not running — this is a standalone script.
    await mongoose.connect(process.env.MONGO_URI);

    // --- 8. Check if Admin Already Exists ---
    // Admin.findOne({ email }) searches the "admins" collection
    // for a document with this email address.
    // If found, we skip creation and exit to prevent duplicates.
    const existing = await Admin.findOne({ email });
    if (existing) {
      // Inform the developer that this admin already exists.
      console.log(`Admin already exists: ${email}`);
      process.exit(0); // exit with success code (0 = no error)
    }

    // --- 9. Hash the Password ---
    // bcrypt.hash(password, saltRounds) creates a secure hash.
    // Salt rounds = 10 is the standard for utility scripts.
    const hashedPassword = await bcrypt.hash(password, 10);

    // --- 10. Create the Admin Document ---
    // Admin.create({ ... }) is a shorthand for:
    //   new Admin({ ... }).save()
    // It inserts a single document into the "admins" collection.
    // name: "Admin" is a default display name (can be changed manually later).
    await Admin.create({ name: "Admin", email, password: hashedPassword });

    // --- 11. Confirm Creation ---
    // Print a success message so the developer knows it worked.
    console.log(`Admin created: ${email}`);

    // Exit successfully.
    process.exit(0);

  } catch (error) {

    // --- 12. Error Handling ---
    // If anything fails (connection issue, schema validation error, etc.),
    // log the full error object and exit with code 1 (failure).
    console.log(error);
    process.exit(1); // non-zero exit code signals failure to shell scripts
  }
};

// --- 13. Run the Script ---
// Calling createAdmin() here immediately executes the function
// when the script is run with: node admin/createAdmin.js
createAdmin();
