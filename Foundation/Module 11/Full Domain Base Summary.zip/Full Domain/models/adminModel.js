// ============================================================
// FILE: models/adminModel.js
// ROLE IN MVC: MODEL Layer — Admin
// PURPOSE: Defines the schema for Admin documents in MongoDB.
//          Admins are stored in a SEPARATE collection from Users
//          ("admins" collection) to keep authentication concerns
//          clean and isolated.
//
// MVC Concept: Having a dedicated Admin model means:
//   - Admin credentials are never mixed with user credentials.
//   - Deleting or editing users cannot accidentally affect admins.
//   - adminAuth middleware can query this model independently.
// ============================================================

// --- 1. Import Mongoose ---
// mongoose is required to create Schemas and Models.
const mongoose = require("mongoose");

// --- 2. Define the Admin Schema ---
// Describes the structure of each document in the "admins" collection.
const adminSchema = new mongoose.Schema({

  // --- 2a. name field ---
  // type: String  → administrator's display name (e.g., "Admin")
  // required: true → every admin document must have a name
  // trim: true    → removes surrounding whitespace automatically
  name: {
    type: String,
    required: true,
    trim: true,
  },

  // --- 2b. email field ---
  // type: String  → used as the login username for the admin
  // required: true → admin cannot exist without an email
  // unique: true  → prevents two admins with the same email
  // trim: true    → keeps email values consistent
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },

  // --- 2c. password field ---
  // type: String  → stores the BCRYPT-hashed password
  // required: true → an admin must always have a password set
  // The createAdmin.js script hashes the password before saving.
  password: {
    type: String,
    required: true,
  },
});

// --- 3. Create the Mongoose Model ---
// mongoose.model("Admin", adminSchema) registers the model under
// the name "Admin". MongoDB will store documents in the "admins"
// collection (automatically pluralized and lowercased).
// This Model class provides query methods:
//   Admin.findOne(), Admin.findById(), Admin.create(), etc.
const Admin = mongoose.model("Admin", adminSchema);

// --- 4. Export the Model ---
// Exported so adminService.js and adminAuth.js can import it
// and perform database queries against the "admins" collection.
module.exports = Admin;
