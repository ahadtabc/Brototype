// ============================================================
// FILE: models/userModel.js
// ROLE IN MVC: MODEL Layer — User
// PURPOSE: Defines the shape (schema) of a User document in
//          MongoDB and exports the Mongoose Model class that
//          Controllers and Services use to query the database.
//
// MVC Concept: The MODEL is the only layer that knows about
//   the database structure. Controllers never talk to MongoDB
//   directly; they talk to Services which use Models.
// ============================================================

// --- 1. Import Mongoose ---
// Required to create Schemas and Models that represent
// MongoDB collections as JavaScript objects.
const mongoose = require("mongoose");

// --- 2. Define the User Schema ---
// A Mongoose Schema describes what fields a document in the
// "users" collection must have, their types, and validation rules.
// Think of it as a blueprint or class definition.
const userSchema = new mongoose.Schema({

  // --- 2a. name field ---
  // type: String  → the value must be a JavaScript string
  // required: true → MongoDB will reject a document without a name
  // trim: true    → automatically removes leading/trailing whitespace
  //                  (e.g., "  Alice  " is saved as "Alice")
  name: {
    type: String,
    required: true,
    trim: true,
  },

  // --- 2b. email field ---
  // type: String  → must be a string value
  // required: true → cannot create a user without an email
  // unique: true  → MongoDB creates a unique index on this field,
  //                  meaning no two documents can share the same email
  // trim: true    → strips whitespace to prevent duplicate detection errors
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },

  // --- 2c. password field ---
  // type: String  → stores the HASHED password (never plain text)
  // required: true → a user document must always have a password
  // NOTE: Passwords are hashed with bcrypt in the Controller
  //       BEFORE being passed to the Service for saving.
  password: {
    type: String,
    required: true,
  },

  // --- 2d. role field ---
  // type: String  → either "user" or "admin"
  // default: "user" → if role is not specified during creation,
  //                    Mongoose automatically sets it to "user".
  //                    This prevents accidental admin privilege escalation.
  role: {
    type: String,
    default: "user",
  },
});

// --- 3. Create the Mongoose Model ---
// mongoose.model("User", userSchema) creates a Model class
// named "User" (Mongoose will use the plural lowercase "users"
// as the MongoDB collection name automatically).
// The Model class provides static methods like:
//   User.find(), User.findById(), User.findOne(),
//   User.findByIdAndUpdate(), User.findByIdAndDelete()
const User = mongoose.model("User", userSchema);

// --- 4. Export the Model ---
// Services import 'User' to perform CRUD operations.
// Nothing else in the codebase accesses MongoDB directly.
module.exports = User;
