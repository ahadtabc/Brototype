// ============================================================
// FILE: config/db.js
// ROLE IN MVC: Infrastructure / Configuration Layer
// PURPOSE: Establishes the connection between the Node.js
//          application and the MongoDB database.
//          The MODEL layer (userModel, adminModel) depends on
//          this connection being open before any query runs.
// ============================================================

// --- 1. Import Mongoose ---
// 'mongoose' is an ODM (Object Data Modeler) for MongoDB.
// It provides:
//   - Schema definitions (structure/validation for documents)
//   - Model classes (User, Admin) to query the database
//   - The connection API (mongoose.connect)
const mongoose = require("mongoose");

// --- 2. Define the connectDB Async Function ---
// We wrap the connection logic in an async arrow function so we
// can use 'await' for the asynchronous mongoose.connect() call.
// This function is called once at server startup (in app.js).
const connectDB = async () => {

  // --- 3. Try / Catch for Safe Connection Handling ---
  // Database connection can fail (wrong URI, MongoDB not running,
  // network issues). The try/catch prevents an unhandled crash.
  try {

    // --- 4. Connect to MongoDB ---
    // mongoose.connect() returns a Promise. 'await' pauses
    // execution until the connection succeeds or throws an error.
    // process.env.MONGO_URI reads the connection string from .env
    // (e.g., "mongodb://127.0.0.1:27017/userDB").
    // This is the local MongoDB address: 127.0.0.1 = localhost,
    // port 27017 is MongoDB's default port, "userDB" is the
    // database name (MongoDB creates it automatically if absent).
    await mongoose.connect(process.env.MONGO_URI);

    // --- 5. Success Log ---
    // Printed to the terminal when the connection is established.
    // Useful during development to confirm DB is reachable.
    console.log("MongoDB connected successfully");

  } catch (error) {

    // --- 6. Error Log ---
    // If mongoose.connect() fails, the caught 'error' object
    // contains the reason. We print error.message for a readable
    // error description without a full stack trace.
    console.log("MongoDB connection failed:", error.message);

    // --- 7. Exit the Process on Failure ---
    // process.exit(1) terminates the Node.js process with exit code 1
    // (non-zero = failure). This is intentional — if the database
    // is unavailable, the application cannot serve data, so it is
    // better to stop immediately than to silently fail later.
    process.exit(1);
  }
};

// --- 8. Export the Function ---
// module.exports makes connectDB available to app.js via require().
// Only the function reference is exported, not the result.
module.exports = connectDB;
