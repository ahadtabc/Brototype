// ============================================================
// FILE: routes/userRoute.js
// ROLE IN MVC: ROUTER Layer — User-facing routes
// PURPOSE: Maps incoming HTTP requests (method + URL path) to
//          the correct Controller method. This file does NOT
//          contain any business logic; it only connects URLs
//          to handlers.
//
// MVC Concept: Routes are the "traffic directors" of the app.
//   They sit between the HTTP layer and the Controller layer.
//   A Router delegates work; it never processes data itself.
// ============================================================

// --- 1. Import Express ---
// express is required to create the Router object.
const express = require("express");

// --- 2. Create a Router Instance ---
// express.Router() creates a mini Express application that can
// have its own middleware and routes.
// This router is mounted in app.js at the root path ("/")
// with: app.use("/", userRoute)
const user = express.Router();

// --- 3. Import the UserController ---
// userController is an INSTANCE of the UserController class
// (see controllers/userController.js).
// Each property on it (getLogin, postLogin, etc.) is a method
// that handles the business logic for a specific action.
const userController = require("../controllers/userController");

// --- 4. Import the userAuth Middleware ---
// This is a route guard. When placed between the path and the
// controller method, it acts as a checkpoint:
//   user.get("/dashboard", userAuth, userController.getDashboard)
//                             ↑ guard runs FIRST, then controller
const userAuth = require("../middleware/userAuth");

// --- 5. Cache-Control Middleware (scoped to user routes) ---
// This middleware runs on EVERY request to the user router.
// It sets a Cache-Control header to prevent browsers from
// caching authenticated pages. Without this, pressing the
// browser Back button after logout could show a cached dashboard.
// This reinforces the same headers set in app.js.
user.use((req, res, next) => {
  res.setHeader(
    "Cache-Control",
    "no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0",
  );
  next(); // continue to the matched route handler
});

// --- 6. Root Route: GET "/" ---
// When a user visits the root URL (http://localhost:3001/),
// they are immediately redirected to the login page.
// This prevents showing a blank or undefined page at the root.
user.get("/", (req, res) => {
  res.redirect("/login"); // send the browser to /login
});

// --- 7. Login Routes ---
// GET  /login → renders the login form (views/user/login.hbs)
//               Also shows success/error messages if redirected here.
// POST /login → receives the submitted form data and authenticates the user.
user.get("/login",  userController.getLogin);   // show login page
user.post("/login", userController.postLogin);  // process login form

// --- 8. Signup Routes ---
// GET  /signup → renders the signup form (views/user/signup.hbs)
// POST /signup → receives form data, validates, hashes password, saves user.
user.get("/signup",  userController.getSignup);  // show signup page
user.post("/signup", userController.postSignup); // process signup form

// --- 9. User Dashboard Route (Protected) ---
// GET /user/userDashboard → renders the user's home page.
// 'userAuth' middleware runs BEFORE getDashboard.
// If the user is not logged in, userAuth redirects to /login.
// Only authenticated users reach getDashboard.
user.get("/user/userDashboard", userAuth, userController.getDashboard);

// --- 10. Logout Route ---
// GET /logout → destroys the session, clears the cookie,
//               and redirects the user back to /login.
// No authentication guard needed here; logging out is always allowed.
user.get("/logout", userController.logout);

// --- 11. Export the Router ---
// app.js imports this and mounts it:
//   app.use("/", user)
// This means all routes defined above are reachable at root paths.
module.exports = user;