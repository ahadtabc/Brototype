// ============================================================
// FILE: routes/adminRoute.js
// ROLE IN MVC: ROUTER Layer — Admin-facing routes
// PURPOSE: Maps all /admin/* HTTP requests to the appropriate
//          AdminController method. Many routes are protected by
//          the adminAuth middleware so only authenticated admins
//          can access them.
//
// MVC Concept: Routes only DECLARE what URL triggers which
//   Controller. No business logic lives here.
// All routes in this file are prefixed with "/admin" because
// app.js mounts this router with: app.use("/admin", adminRoute)
// ============================================================

// --- 1. Import Express ---
// Needed to create the Router object.
const express = require("express");

// --- 2. Create Router Instance ---
// This router handles all paths under "/admin".
// Example: admin.get("/") handles GET /admin
//          admin.get("/adminUsers") handles GET /admin/adminUsers
const admin = express.Router();

// --- 3. Import the AdminController ---
// An instance of AdminController that contains all the handler
// methods for admin pages (login, user management, logout, etc.)
const adminController = require("../controllers/adminController");

// --- 4. Import the adminAuth Middleware ---
// Route guard that checks if the requester has an active admin
// session before allowing access to protected admin pages.
const adminAuth = require("../middleware/adminAuth");

// --- 5. Cache-Control Middleware (scoped to admin routes) ---
// Runs on every request to the admin router.
// Prevents the browser from caching admin pages.
// Without this, a logged-out admin could press Back and see
// a cached version of the admin dashboard.
admin.use((req, res, next) => {
  res.setHeader(
    "Cache-Control",
    "no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0",
  );
  next(); // pass to the matching route handler
});

// --- 6. Admin Login Routes ---
// GET  /admin    → renders the admin login form (admin/login.hbs)
//                  Also serves as the "entry point" to the admin panel.
// POST /admin/login → processes the login form and authenticates the admin.
// Neither of these is protected by adminAuth (you need to log in first).
admin.get("/",       adminController.getLogin);   // show admin login page
admin.post("/login", adminController.postLogin);  // handle admin login form

// --- 7. Admin Dashboard Route (Protected) ---
// GET /admin/adminDashboard → currently redirects to /admin/adminUsers.
// Protected: only accessible if the admin is logged in.
// The 'adminAuth' middleware is the second argument, running before
// 'adminController.getDashboard'.
admin.get("/adminDashboard", adminAuth, adminController.getDashboard);

// --- 8. Manage Users Route (Protected) ---
// GET /admin/adminUsers → renders the full user management table
//   with pagination and search support.
// This is the main admin panel page showing all regular users.
admin.get("/adminUsers", adminAuth, adminController.getUsers);

// --- 9. Add User Routes (Protected) ---
// GET  /admin/addUser → renders the "Create New User" form.
// POST /admin/addUser → processes the form: validates, hashes password,
//                        saves the new user to the database.
admin.get("/addUser",  adminAuth, adminController.getAddUser);  // show form
admin.post("/addUser", adminAuth, adminController.postAddUser); // handle form

// --- 10. Edit User Routes (Protected) ---
// GET  /admin/editUser/:id → renders the edit form pre-filled with
//   the user's current data. ':id' is a URL parameter (the user's _id).
//   Example URL: /admin/editUser/64b1a2c3d4e5f67890abcdef
// POST /admin/editUser/:id → processes the edit: updates name, email,
//   and optionally re-hashes a new password if one was provided.
admin.get("/editUser/:id",  adminAuth, adminController.getEditUser);  // show edit form
admin.post("/editUser/:id", adminAuth, adminController.postEditUser); // save changes

// --- 11. Delete User Route (Protected) ---
// GET /admin/deleteUser/:id → finds the user by :id and deletes
//   their document from the database, then redirects back to the list.
// NOTE: Using GET for a delete action is a simplification. In
//   production, this should be a POST or DELETE HTTP method to
//   prevent accidental deletion via link pre-fetching.
admin.get("/deleteUser/:id", adminAuth, adminController.deleteUser);

// --- 12. Logout Route ---
// GET /admin/logout → destroys the admin session, clears the cookie,
//   and redirects to the admin login page (/admin).
// Not protected by adminAuth because you should be able to log out at any time.
admin.get("/logout", adminController.logout);

// --- 13. Export the Router ---
// app.js imports this and mounts it at /admin:
//   app.use("/admin", admin)
// This means all routes above are accessible at /admin/[path].
module.exports = admin;